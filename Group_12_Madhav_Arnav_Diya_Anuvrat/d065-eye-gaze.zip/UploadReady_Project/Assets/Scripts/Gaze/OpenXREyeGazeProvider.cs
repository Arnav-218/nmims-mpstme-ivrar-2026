using System;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.InputSystem.XR;

namespace IVRAR.CybersecurityVR
{
    /// <summary>
    /// Genuine OpenXR Eye-Gaze acquisition provider.
    /// Operates against the Unity Input System using standard OpenXR / XR layout bindings
    /// (&lt;EyeGaze&gt;/pose, &lt;EyeGaze&gt;/trackingState, &lt;Eyes&gt;).
    /// Converts gaze coordinates from tracking space to world space via the XR Origin / Camera hierarchy.
    /// </summary>
    public class OpenXREyeGazeProvider : IGazeSampleProvider
    {
        public string ProviderName => "OpenXR Eye Gaze Provider";
        public GazeProvenance Provenance => GazeProvenance.EyeTracking_OpenXR;

        private Transform _trackingOrigin;
        private Camera _referenceCamera;

        private InputAction _gazePoseAction;
        private InputAction _trackingStateAction;
        private InputAction _eyesControlAction;

        private bool _isInitialized;
        private bool _deviceDetected;

        public bool IsAvailable => _isInitialized && _deviceDetected;

        public void Initialize(Transform trackingOrigin, Camera referenceCamera)
        {
            _trackingOrigin = trackingOrigin;
            _referenceCamera = referenceCamera;

            // Bind to standard OpenXR Eye Gaze pose and trackingState
            _gazePoseAction = new InputAction("OpenXR_GazePose", binding: "<EyeGaze>/pose");
            _trackingStateAction = new InputAction("OpenXR_GazeTrackingState", binding: "<EyeGaze>/trackingState");
            _eyesControlAction = new InputAction("OpenXR_EyesDevice", binding: "<Eyes>/fixationPoint");

            try
            {
                _gazePoseAction.Enable();
                _trackingStateAction.Enable();
                _eyesControlAction.Enable();
            }
            catch (Exception ex)
            {
                Debug.LogWarning($"[OpenXREyeGazeProvider] Could not enable OpenXR input bindings: {ex.Message}");
            }

            InputSystem.onDeviceChange += OnDeviceChange;
            _isInitialized = true;
            CheckDeviceAvailability();
        }

        private void OnDeviceChange(InputDevice device, InputDeviceChange change)
        {
            if (change == InputDeviceChange.Added ||
                change == InputDeviceChange.Removed ||
                change == InputDeviceChange.Reconnected ||
                change == InputDeviceChange.Disconnected)
            {
                CheckDeviceAvailability();
            }
        }

        public void CheckDeviceAvailability()
        {
            _deviceDetected = false;

            // Check if any device matches EyeGaze or Eyes layout
            foreach (var device in InputSystem.devices)
            {
                if (device == null) continue;
                string layout = device.layout ?? string.Empty;
                string name = device.name ?? string.Empty;

                if (layout.IndexOf("EyeGaze", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    layout.IndexOf("Eyes", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    name.IndexOf("EyeGaze", StringComparison.OrdinalIgnoreCase) >= 0 ||
                    name.IndexOf("Eyes", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    _deviceDetected = true;
                    Debug.Log($"[OpenXREyeGazeProvider] Eye-tracking device detected: {device.displayName} (layout={layout})");
                    break;
                }
            }

            // Also check if pose control has an active bound control
            if (!_deviceDetected && _gazePoseAction != null && _gazePoseAction.controls.Count > 0)
            {
                _deviceDetected = true;
            }
        }

        public bool AcquireSample(out GazeSample sample)
        {
            double now = Time.unscaledTimeAsDouble;

            if (!IsAvailable)
            {
                sample = GazeSample.Invalid(now, Provenance, ProviderName);
                return false;
            }

            // Check tracking state (InputTrackingState bitmask: 1=Position, 2=Rotation)
            int trackingState = 0;
            if (_trackingStateAction != null && _trackingStateAction.controls.Count > 0)
            {
                try
                {
                    trackingState = _trackingStateAction.ReadValue<int>();
                }
                catch
                {
                    trackingState = 0;
                }
            }
            else
            {
                // If trackingState is not published separately, assume tracked if pose action bound
                trackingState = 3;
            }

            // Pose bitmask: rotation is essential (bit 1, value 2); position is bit 0 (value 1)
            bool isRotationTracked = (trackingState & 2) != 0 || trackingState == 3;
            if (!isRotationTracked)
            {
                sample = GazeSample.Invalid(now, Provenance, ProviderName);
                return false;
            }

            Pose localPose = Pose.identity;
            bool readSuccess = false;

            if (_gazePoseAction != null && _gazePoseAction.controls.Count > 0)
            {
                try
                {
                    localPose = _gazePoseAction.ReadValue<Pose>();
                    readSuccess = true;
                }
                catch
                {
                    readSuccess = false;
                }
            }

            // Reject identity/zero/NaN poses
            if (!readSuccess ||
                float.IsNaN(localPose.position.x) ||
                float.IsNaN(localPose.rotation.x) ||
                (localPose.position == Vector3.zero && localPose.rotation == Quaternion.identity))
            {
                sample = GazeSample.Invalid(now, Provenance, ProviderName);
                return false;
            }

            // Transform tracking-space pose to world-space
            Transform originTransform = _trackingOrigin != null ? _trackingOrigin :
                (_referenceCamera != null && _referenceCamera.transform.parent != null ? _referenceCamera.transform.parent :
                 (_referenceCamera != null ? _referenceCamera.transform : null));

            Vector3 worldOrigin;
            Vector3 worldDirection;

            if (originTransform != null)
            {
                worldOrigin = originTransform.TransformPoint(localPose.position);
                worldDirection = originTransform.TransformDirection(localPose.rotation * Vector3.forward).normalized;
            }
            else
            {
                worldOrigin = localPose.position;
                worldDirection = (localPose.rotation * Vector3.forward).normalized;
            }

            sample = new GazeSample(
                now,
                worldOrigin,
                worldDirection,
                true,
                1.0f,
                Provenance,
                ProviderName
            );
            return true;
        }

        public void Shutdown()
        {
            InputSystem.onDeviceChange -= OnDeviceChange;

            _gazePoseAction?.Disable();
            _gazePoseAction?.Dispose();
            _gazePoseAction = null;

            _trackingStateAction?.Disable();
            _trackingStateAction?.Dispose();
            _trackingStateAction = null;

            _eyesControlAction?.Disable();
            _eyesControlAction?.Dispose();
            _eyesControlAction = null;

            _isInitialized = false;
            _deviceDetected = false;
        }
    }
}
