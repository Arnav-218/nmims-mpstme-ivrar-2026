using System;
using UnityEngine;
using TMPro;

#if UNITY_EDITOR
using UnityEditor;
#endif

namespace IVRAR.CybersecurityVR
{
    /// <summary>
    /// Utility component that automatically sizes and positions a BoxCollider
    /// to tightly enclose a RectTransform UI element or TextMeshPro text bounding box.
    /// Provides both runtime configuration and Editor menu tooling.
    /// </summary>
    [RequireComponent(typeof(BoxCollider))]
    public class GazeAOIColliderFitter : MonoBehaviour
    {
        [Tooltip("Additional padding added to the width and height (local units).")]
        [SerializeField] private Vector2 _padding = new Vector2(0.01f, 0.01f);

        [Tooltip("Thickness along the local Z axis for robust 3D raycast intersection (e.g. 0.02m = 2cm).")]
        [SerializeField] private float _zThickness = 0.02f;

        [Tooltip("Center offset along Z to ensure the collider faces outward from the canvas plane.")]
        [SerializeField] private float _zOffset = 0.0f;

        [Tooltip("If true, automatically fits the collider on Start().")]
        [SerializeField] private bool _fitOnStart = true;

        private void Start()
        {
            if (_fitOnStart)
            {
                FitCollider();
            }
        }

        [ContextMenu("Fit Collider to Bounds")]
        public void FitCollider()
        {
            var box = GetComponent<BoxCollider>();
            if (box == null) box = gameObject.AddComponent<BoxCollider>();

            var tmp = GetComponent<TextMeshProUGUI>();
            var rectTransform = GetComponent<RectTransform>();

            if (tmp != null && !string.IsNullOrEmpty(tmp.text))
            {
                // Fit to TextMeshPro text geometry bounds
                tmp.ForceMeshUpdate();
                var textBounds = tmp.textBounds;
                box.center = new Vector3(textBounds.center.x, textBounds.center.y, _zOffset);
                box.size = new Vector3(
                    Mathf.Max(textBounds.size.x + _padding.x, 0.01f),
                    Mathf.Max(textBounds.size.y + _padding.y, 0.01f),
                    _zThickness
                );
            }
            else if (rectTransform != null)
            {
                // Fit to RectTransform rect bounds
                Rect rect = rectTransform.rect;
                box.center = new Vector3(rect.center.x, rect.center.y, _zOffset);
                box.size = new Vector3(
                    Mathf.Max(rect.width + _padding.x, 0.01f),
                    Mathf.Max(rect.height + _padding.y, 0.01f),
                    _zThickness
                );
            }
            else
            {
                Debug.LogWarning($"[GazeAOIColliderFitter] No RectTransform or TextMeshProUGUI found on {gameObject.name}. Collider size unchanged.");
            }

            // Ensure isTrigger is enabled for non-blocking UI interactions
            box.isTrigger = true;
        }

#if UNITY_EDITOR
        [MenuItem("IVRAR/Fit All AOI Colliders in Scene")]
        public static void FitAllCollidersInScene()
        {
#if UNITY_6000_0_OR_NEWER
            var fitters = UnityEngine.Object.FindObjectsByType<GazeAOIColliderFitter>();
#else
            var fitters = UnityEngine.Object.FindObjectsOfType<GazeAOIColliderFitter>();
#endif
            foreach (var fitter in fitters)
            {
                fitter.FitCollider();
                EditorUtility.SetDirty(fitter.gameObject);
            }
            Debug.Log($"[GazeAOIColliderFitter] Successfully updated {fitters.Length} AOI colliders.");
        }
#endif
    }
}
