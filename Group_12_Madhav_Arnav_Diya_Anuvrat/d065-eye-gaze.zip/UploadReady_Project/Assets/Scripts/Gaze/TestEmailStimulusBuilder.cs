using System;
using UnityEngine;

namespace IVRAR.CybersecurityVR
{
    /// <summary>
    /// Constructs a self-contained test email stimulus using primitive colliders.
    /// Allows immediate PlayMode and simulator testing without requiring Person 3's workstation scene.
    /// Demonstrates the AOI nesting and priority hierarchy (e.g. SenderDomain over SenderHeader, Hyperlink over EmailBody).
    /// </summary>
    public class TestEmailStimulusBuilder : MonoBehaviour
    {
        [Tooltip("If true, automatically builds the primitive email stimulus on Start().")]
        [SerializeField] private bool _buildOnStart = true;

        [Tooltip("Distance in front of the camera to position the email stimulus panel.")]
        [SerializeField] private float _panelDistance = 1.2f;

        private void Start()
        {
            if (_buildOnStart)
            {
                BuildStimulus();
            }
        }

        [ContextMenu("Build Test Email Stimulus")]
        public void BuildStimulus()
        {
            // Clear existing children
            for (int i = transform.childCount - 1; i >= 0; i--)
            {
                DestroyImmediate(transform.GetChild(i).gameObject);
            }

            transform.position = new Vector3(0, 1.3f, _panelDistance);
            transform.rotation = Quaternion.identity;

            int aoiLayer = LayerMask.NameToLayer("GazeAOI");
            if (aoiLayer == -1)
            {
                Debug.LogWarning("[TestEmailStimulusBuilder] Layer 'GazeAOI' not found. Using Default layer for test objects.");
                aoiLayer = 0;
            }

            // 1. Email Body Background (Base panel)
            var bodyObj = CreatePrimitiveElement("AOI_EmailBody", transform, new Vector3(0, 0, 0), new Vector3(0.8f, 0.6f, 0.02f), new Color(0.95f, 0.95f, 0.95f), aoiLayer);
            var bodyAoi = bodyObj.AddComponent<GazeAOITarget>();
            bodyAoi.Configure(AOIType.EmailBody, "email_body", priority: 1);

            // 2. Sender Header
            var headerObj = CreatePrimitiveElement("AOI_SenderHeader", transform, new Vector3(-0.05f, 0.22f, -0.015f), new Vector3(0.65f, 0.08f, 0.02f), new Color(0.85f, 0.88f, 0.92f), aoiLayer);
            var headerAoi = headerObj.AddComponent<GazeAOITarget>();
            headerAoi.Configure(AOIType.SenderHeader, "sender_header", priority: 10);

            // 3. Sender Domain (Nested inside header, higher priority)
            var domainObj = CreatePrimitiveElement("AOI_SenderDomain", headerObj.transform, new Vector3(0.12f, 0, -0.015f), new Vector3(0.35f, 0.06f, 0.02f), new Color(0.7f, 0.8f, 0.95f), aoiLayer);
            var domainAoi = domainObj.AddComponent<GazeAOITarget>();
            domainAoi.Configure(AOIType.SenderDomain, "sender_domain", priority: 20);

            // 4. Security Badge
            var badgeObj = CreatePrimitiveElement("AOI_SecurityBadge", transform, new Vector3(0.32f, 0.22f, -0.015f), new Vector3(0.08f, 0.08f, 0.02f), new Color(0.3f, 0.8f, 0.4f), aoiLayer);
            var badgeAoi = badgeObj.AddComponent<GazeAOITarget>();
            badgeAoi.Configure(AOIType.SecurityBadge, "security_badge", priority: 15);

            // 5. Subject Line
            var subjectObj = CreatePrimitiveElement("AOI_SubjectLine", transform, new Vector3(0, 0.12f, -0.015f), new Vector3(0.72f, 0.06f, 0.02f), new Color(0.88f, 0.88f, 0.88f), aoiLayer);
            var subjectAoi = subjectObj.AddComponent<GazeAOITarget>();
            subjectAoi.Configure(AOIType.SubjectLine, "subject_line", priority: 10);

            // 6. Hyperlink Target (Inside body, higher priority)
            var linkObj = CreatePrimitiveElement("AOI_HyperlinkTarget", transform, new Vector3(0, -0.10f, -0.015f), new Vector3(0.40f, 0.05f, 0.02f), new Color(0.2f, 0.4f, 0.9f), aoiLayer);
            var linkAoi = linkObj.AddComponent<GazeAOITarget>();
            linkAoi.Configure(AOIType.HyperlinkTarget, "hyperlink_target", priority: 20);

            // 7. Surrounding Room Background
            var bgObj = CreatePrimitiveElement("AOI_RoomBackground", transform, new Vector3(0, 0, 0.5f), new Vector3(3.0f, 2.0f, 0.02f), new Color(0.2f, 0.2f, 0.25f), aoiLayer);
            var bgAoi = bgObj.AddComponent<GazeAOITarget>();
            bgAoi.Configure(AOIType.IrrelevantBackground, "room_background", priority: -10);

            Debug.Log("[TestEmailStimulusBuilder] Built primitive email stimulus with 7 AOI targets.");
        }

        private GameObject CreatePrimitiveElement(string name, Transform parent, Vector3 localPos, Vector3 localScale, Color color, int layer)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Cube);
            go.name = name;
            go.layer = layer;
            go.transform.SetParent(parent, false);
            go.transform.localPosition = localPos;
            go.transform.localScale = localScale;

            var renderer = go.GetComponent<Renderer>();
            if (renderer != null)
            {
                renderer.material.color = color;
            }

            var col = go.GetComponent<BoxCollider>();
            if (col != null)
            {
                col.isTrigger = true;
            }

            return go;
        }
    }
}
