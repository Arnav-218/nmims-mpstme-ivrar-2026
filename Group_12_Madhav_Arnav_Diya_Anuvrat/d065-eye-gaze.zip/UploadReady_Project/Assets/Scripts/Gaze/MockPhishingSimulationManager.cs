using System;
using UnityEngine;

namespace IVRAR.CybersecurityVR
{
    /// <summary>
    /// Mock scenario lifecycle manager representing Person 2's PhishingThreatSimulationManager.
    /// Used for standalone testing, automated test execution, and reference implementation.
    /// </summary>
    public class MockPhishingSimulationManager : MonoBehaviour
    {
        [Header("Connected Bridge")]
        [SerializeField] private EyeGazeScenarioBridge _bridge;

        public event Action<string, string> OnTrialStarted;
        public event Action<PhishingTrialOutcome, double, string, string> OnTrialEnded;
        public event Action<string> OnTrialAborted;

        private void Awake()
        {
            if (_bridge == null)
            {
                _bridge = GetComponent<EyeGazeScenarioBridge>();
            }
        }

        public void TriggerTrialStart(string trialId, string scenarioId)
        {
            OnTrialStarted?.Invoke(trialId, scenarioId);
            if (_bridge != null)
            {
                _bridge.OnScenarioTrialStarted(trialId, scenarioId);
            }
        }

        public void TriggerTrialEnd(PhishingTrialOutcome outcome, double responseTimeMs, string leverId = "LEVER_REPORT", string notes = "")
        {
            OnTrialEnded?.Invoke(outcome, responseTimeMs, leverId, notes);
            if (_bridge != null)
            {
                _bridge.OnScenarioTrialEnded(outcome, responseTimeMs, leverId, notes);
            }
        }

        public void TriggerTrialAbort(string reason)
        {
            OnTrialAborted?.Invoke(reason);
            if (_bridge != null)
            {
                _bridge.OnScenarioTrialAborted(reason);
            }
        }
    }
}
