using System;
using UnityEngine;

namespace IVRAR.CybersecurityVR
{
    /// <summary>
    /// Central manager for the Eye-Gaze and Attention Tracking Subsystem.
    /// Manages provider lifecycle, physics AOI raycasting, I-DT fixation detection,
    /// threat inspection ratio (R_inspect) accumulation, and RFC 4180 CSV data export.
    /// </summary>
    [DisallowMultipleComponent]
    [DefaultExecutionOrder(-50)]
    public class EyeGazeAttentionTracker : MonoBehaviour
    {
        [Header("Gaze Acquisition Policy")]
        [Tooltip("Operating policy dictating acceptable gaze acquisition providers.")]
        [SerializeField] private TrackerPolicy _policy = TrackerPolicy.PreferRealThenFallback;

        [Header("Hierarchy References")]
        [Tooltip("Transform representing the tracking space origin (e.g. XR Origin / Camera Offset).")]
        [SerializeField] private Transform _trackingOrigin = null;

        [Tooltip("Main XR Camera rendering the user's viewpoint.")]
        [SerializeField] private Camera _referenceCamera = null;

        [Header("Raycast & AOI Layer Configuration")]
        [Tooltip("LayerMask containing the 'GazeAOI' layer. Tracker verifies this on startup.")]
        [SerializeField] private LayerMask _gazeAoiLayerMask;

        [Tooltip("Maximum raycast distance in meters.")]
        [SerializeField] private float _maxRaycastDistance = 15.0f;

        [Tooltip("Whether trigger colliders are checked during raycasting.")]
        [SerializeField] private QueryTriggerInteraction _triggerInteraction = QueryTriggerInteraction.Collide;

        [Header("Simulation Settings")]
        [Tooltip("Deterministic scripted gaze sequence to execute in SimulatorOnly mode or automated tests.")]
        [SerializeField] private ScriptedGazeSequence _scriptedSequence;

        [Tooltip("Sub-mode for the simulator: interactive mouse or deterministic scripted timeline.")]
        [SerializeField] private SimulationSubMode _simulationSubMode = SimulationSubMode.InteractiveMouse;

        [Header("Algorithms & Thresholds")]
        [SerializeField] private FixationDetector.Settings _fixationSettings = FixationDetector.Settings.Default;
        [SerializeField] private GazeMetricsAccumulator.Settings _metricsSettings = GazeMetricsAccumulator.Settings.Default;

        [Header("Data Export")]
        [Tooltip("If true, automatically exports CSV and JSON metadata upon EndTrial().")]
        [SerializeField] private bool _autoExportOnTrialEnd = true;

        [Tooltip("Custom export directory path (null uses Application.persistentDataPath).")]
        [SerializeField] private string _customExportPath = null;

        // Public Events
        public event Action<FixationRecord> OnFixationCompleted;
        public event Action<GazeTrialSummary> OnTrialMetricsReady;
        public event Action<GazeProvenance, string> OnProviderChanged;
        public event Action OnTrackingLost;
        public event Action OnTrackingRegained;

        // Runtime State
        private IGazeSampleProvider _activeProvider;
        private FixationDetector _fixationDetector;
        private GazeMetricsAccumulator _metricsAccumulator;

        private bool _isTrialActive = false;
        private TrialContext _currentContext;
        private GazeTrialSummary _lastTrialSummary;
        private bool _lastTrackingValidState = false;

        private GazeSample _latestSample;
        private AOIType _latestHitAoiType = AOIType.IrrelevantBackground;
        private string _latestHitAoiId = string.Empty;

        // Preallocated Raycast Buffer (Rule 3: NonAlloc)
        private readonly RaycastHit[] _raycastHits = new RaycastHit[16];

        // Public Properties
        public bool IsTracking => _activeProvider != null && _activeProvider.IsAvailable;
        public bool IsTrialActive => _isTrialActive;
        public TrackerPolicy Policy => _policy;
        public GazeProvenance CurrentProvenance => _activeProvider != null ? _activeProvider.Provenance : GazeProvenance.HeadDirection_Fallback;
        public IGazeSampleProvider ActiveProvider => _activeProvider;
        public GazeSample LatestSample => _latestSample;
        public AOIType LatestHitAoiType => _latestHitAoiType;
        public string LatestHitAoiId => _latestHitAoiId;
        public GazeTrialSummary LastTrialSummary => _lastTrialSummary;

        private void Awake()
        {
            ValidateAoiLayerConfiguration();

            if (_referenceCamera == null)
            {
                _referenceCamera = Camera.main;
            }

            _fixationDetector = new FixationDetector(_fixationSettings);
            _metricsAccumulator = new GazeMetricsAccumulator(_metricsSettings);
        }

        private void Start()
        {
            InitializeGazeProvider();
        }

        private void ValidateAoiLayerConfiguration()
        {
            int layerId = LayerMask.NameToLayer("GazeAOI");
            if (layerId == -1)
            {
                Debug.LogError("[EyeGazeAttentionTracker] CRITICAL CONFIGURATION ERROR: Layer 'GazeAOI' is not defined in TagManager! " +
                               "You must create user layer 'GazeAOI' in Project Settings -> Tags and Layers. " +
                               "The tracker will NOT silently fall back to Default layer.");
                throw new InvalidOperationException("GazeAOI layer not defined. Please add it in Project Settings.");
            }
            else
            {
                // Ensure LayerMask includes GazeAOI
                if (_gazeAoiLayerMask == 0)
                {
                    _gazeAoiLayerMask = 1 << layerId;
                }
            }
        }

        public void SetPolicy(TrackerPolicy policy)
        {
            _policy = policy;
            InitializeGazeProvider();
        }

        public void SetScriptedSequence(ScriptedGazeSequence sequence)
        {
            _scriptedSequence = sequence;
            if (_activeProvider is SimulatedGazeProvider sim)
            {
                sim.SetSequence(sequence, GazeAOIRegistry.GetTargetWorldPosition);
            }
        }

        public void InitializeGazeProvider()
        {
            _activeProvider?.Shutdown();
            _activeProvider = null;

            switch (_policy)
            {
                case TrackerPolicy.RequireRealEyeTracking:
                {
                    var openXr = new OpenXREyeGazeProvider();
                    openXr.Initialize(_trackingOrigin, _referenceCamera);
                    if (openXr.IsAvailable)
                    {
                        _activeProvider = openXr;
                        Debug.Log($"[EyeGazeAttentionTracker] Genuine OpenXR Eye Tracking successfully initialized.");
                    }
                    else
                    {
                        openXr.Shutdown();
                        Debug.LogError("[EyeGazeAttentionTracker] Policy is RequireRealEyeTracking, but real eye tracking hardware/runtime is unavailable. " +
                                       "Fallback and simulation are disabled per policy. Trial export will be halted.");
                    }
                    break;
                }

                case TrackerPolicy.PreferRealThenFallback:
                {
                    var openXr = new OpenXREyeGazeProvider();
                    openXr.Initialize(_trackingOrigin, _referenceCamera);
                    if (openXr.IsAvailable)
                    {
                        _activeProvider = openXr;
                        Debug.Log($"[EyeGazeAttentionTracker] PreferRealThenFallback: OpenXR eye tracking active.");
                    }
                    else
                    {
                        openXr.Shutdown();
                        var fallback = new HeadDirectionFallbackProvider();
                        fallback.Initialize(_trackingOrigin, _referenceCamera);
                        _activeProvider = fallback;
                        Debug.LogWarning("[EyeGazeAttentionTracker] Real eye tracking unavailable. Falling back to Head Direction. " +
                                         "PROVENANCE WARNING: Samples are explicitly labelled HeadDirection_Fallback and are NOT eye tracking.");
                    }
                    break;
                }

                case TrackerPolicy.SimulatorOnly:
                {
                    var sim = new SimulatedGazeProvider(_simulationSubMode, _scriptedSequence, GazeAOIRegistry.GetTargetWorldPosition);
                    sim.Initialize(_trackingOrigin, _referenceCamera);
                    _activeProvider = sim;
                    Debug.Log($"[EyeGazeAttentionTracker] Simulator active (Mode: {_simulationSubMode}, Provenance: {sim.Provenance}).");
                    break;
                }

                case TrackerPolicy.HeadDirectionOnly:
                {
                    var fallback = new HeadDirectionFallbackProvider();
                    fallback.Initialize(_trackingOrigin, _referenceCamera);
                    _activeProvider = fallback;
                    Debug.Log("[EyeGazeAttentionTracker] Head Direction Fallback provider active.");
                    break;
                }
            }

            if (_activeProvider != null)
            {
                OnProviderChanged?.Invoke(_activeProvider.Provenance, _activeProvider.ProviderName);
            }
        }

        private void Update()
        {
            if (_activeProvider == null) return;

            // 1. Acquire Gaze Sample
            bool sampleAcquired = _activeProvider.AcquireSample(out _latestSample);

            // Tracking lost / regained event dispatch
            if (sampleAcquired && _latestSample.isValid)
            {
                if (!_lastTrackingValidState)
                {
                    _lastTrackingValidState = true;
                    OnTrackingRegained?.Invoke();
                }
            }
            else
            {
                if (_lastTrackingValidState)
                {
                    _lastTrackingValidState = false;
                    OnTrackingLost?.Invoke();
                }
            }

            // 2. Perform AOI Raycast
            PerformAoiRaycast(_latestSample, out _latestHitAoiType, out _latestHitAoiId);

            // 3. Process through Fixation Detector
            if (_fixationDetector.ProcessSample(_latestSample, _latestHitAoiType, _latestHitAoiId, out var completedFixation))
            {
                OnFixationCompleted?.Invoke(completedFixation);
                if (_isTrialActive)
                {
                    _metricsAccumulator.AccumulateFixation(completedFixation);
                }
            }

            // 4. Ingest sample into Metrics Accumulator if trial active
            if (_isTrialActive)
            {
                _metricsAccumulator.AccumulateSample(_latestSample, _latestHitAoiType, _latestHitAoiId);
            }
        }

        private void PerformAoiRaycast(GazeSample sample, out AOIType hitType, out string hitId)
        {
            hitType = AOIType.IrrelevantBackground;
            hitId = "background";

            if (!sample.isValid) return;

            Ray ray = new Ray(sample.originWorld, sample.directionWorld);
            int hitCount = Physics.RaycastNonAlloc(
                ray,
                _raycastHits,
                _maxRaycastDistance,
                _gazeAoiLayerMask,
                _triggerInteraction
            );

            if (hitCount <= 0) return;

            // Overlap resolution rule: highest priority wins; tie-breaker: closest distance
            GazeAOITarget bestTarget = null;
            float bestDistance = float.MaxValue;
            int highestPriority = int.MinValue;

            for (int i = 0; i < hitCount; i++)
            {
                RaycastHit hit = _raycastHits[i];
                if (hit.collider == null) continue;

                if (GazeAOIRegistry.TryGetTarget(hit.collider, out var target))
                {
                    if (target.Priority > highestPriority)
                    {
                        highestPriority = target.Priority;
                        bestTarget = target;
                        bestDistance = hit.distance;
                    }
                    else if (target.Priority == highestPriority && hit.distance < bestDistance)
                    {
                        bestTarget = target;
                        bestDistance = hit.distance;
                    }
                }
            }

            if (bestTarget != null)
            {
                hitType = bestTarget.Type;
                hitId = bestTarget.AoiId;
            }
        }

        #region Public Trial Lifecycle API

        /// <summary>
        /// Begins tracking a new trial scenario.
        /// </summary>
        public void BeginTrial(TrialContext context)
        {
            if (_isTrialActive)
            {
                Debug.LogWarning("[EyeGazeAttentionTracker] BeginTrial called while previous trial was still active! Finalizing prior trial.");
                EndTrial(TrialOutcomeInfo.Empty);
            }

            _currentContext = context;
            _fixationDetector.Reset();

            GazeProvenance prov = _activeProvider != null ? _activeProvider.Provenance : GazeProvenance.HeadDirection_Fallback;
            string srcName = _activeProvider != null ? _activeProvider.ProviderName : "None";
            double now = Time.unscaledTimeAsDouble;

            _metricsAccumulator.InitializeTrial(_currentContext, prov, srcName, now);
            _isTrialActive = true;

            Debug.Log($"[EyeGazeAttentionTracker] Trial Begun: Participant={context.participantPseudoId}, Trial={context.trialId}, Scenario={context.scenarioId}, Provenance={prov}");
        }

        /// <summary>
        /// Concludes the active trial, evaluates open fixations, finalizes research metrics, and exports data.
        /// </summary>
        public void EndTrial(TrialOutcomeInfo outcomeInfo)
        {
            if (!_isTrialActive)
            {
                Debug.LogWarning("[EyeGazeAttentionTracker] EndTrial called but no trial is currently active.");
                return;
            }

            double now = Time.unscaledTimeAsDouble;

            // Finalize any open fixation window
            if (_fixationDetector.FinalizeOpenFixation(out var openFixation))
            {
                OnFixationCompleted?.Invoke(openFixation);
                _metricsAccumulator.AccumulateFixation(openFixation);
            }

            _lastTrialSummary = _metricsAccumulator.FinalizeTrial(now, outcomeInfo);
            _isTrialActive = false;

            OnTrialMetricsReady?.Invoke(_lastTrialSummary);

            Debug.Log($"[EyeGazeAttentionTracker] Trial Ended: Participant={_lastTrialSummary.context.participantPseudoId}, " +
                      $"R_inspect={_lastTrialSummary.rInspect:F4} ({_lastTrialSummary.rInspectFlag}), " +
                      $"TotalDwell={_lastTrialSummary.tTotalDwellMs:F1}ms, Fixations={_lastTrialSummary.totalFixationCount}");

            if (_autoExportOnTrialEnd)
            {
                ExportTrial();
            }
        }

        /// <summary>
        /// Aborts the active trial without saving invalid data, logging the specified reason.
        /// </summary>
        public void AbortTrial(string reason)
        {
            if (!_isTrialActive) return;

            double now = Time.unscaledTimeAsDouble;
            _lastTrialSummary = _metricsAccumulator.FinalizeTrial(now, TrialOutcomeInfo.Empty, reason ?? "UserAborted");
            _isTrialActive = false;

            Debug.LogWarning($"[EyeGazeAttentionTracker] Trial Aborted: Reason='{reason}'");

            if (_autoExportOnTrialEnd)
            {
                ExportTrial();
            }
        }

        /// <summary>
        /// Exports the last completed trial to CSV and writes the companion JSON metadata file.
        /// </summary>
        public bool ExportTrial()
        {
            if (_lastTrialSummary == null)
            {
                Debug.LogWarning("[EyeGazeAttentionTracker] Cannot export: no completed trial summary available.");
                return false;
            }

            // Enforce policy: RequireRealEyeTracking halts export if real hardware was not used
            if (_policy == TrackerPolicy.RequireRealEyeTracking &&
                _lastTrialSummary.provenance != GazeProvenance.EyeTracking_OpenXR &&
                _lastTrialSummary.provenance != GazeProvenance.EyeTracking_VendorSDK)
            {
                Debug.LogError("[EyeGazeAttentionTracker] Export refused: Policy is RequireRealEyeTracking, but trial provenance is not genuine eye tracking.");
                return false;
            }

            bool s1 = GazeCsvWriter.WriteTrialSummary(_lastTrialSummary, _customExportPath);
            bool s2 = GazeCsvWriter.WriteAoiMetrics(_lastTrialSummary, _customExportPath);
            bool s3 = GazeCsvWriter.WriteFixations(_lastTrialSummary, _customExportPath);
            bool s4 = GazeCsvWriter.WriteSessionMetadata(
                _lastTrialSummary.context,
                _lastTrialSummary.provenance,
                _lastTrialSummary.inputSourceName,
                _fixationSettings,
                _metricsSettings,
                _customExportPath
            );

            bool success = s1 && s2 && s3 && s4;
            if (success)
            {
                string dir = GazeCsvWriter.GetSessionDirectory(_lastTrialSummary.context.sessionId, _lastTrialSummary.isSynthetic, _customExportPath);
                Debug.Log($"[EyeGazeAttentionTracker] Successfully exported trial metrics to '{dir}'");
            }
            return success;
        }

        /// <summary>
        /// Resets active buffers. Never erases unexported trial summary data.
        /// </summary>
        public void ResetTracker()
        {
            _fixationDetector?.Reset();
            _metricsAccumulator?.Reset();
            _isTrialActive = false;
        }

        #endregion

        private void OnGUI()
        {
            // Visible on-screen research warning whenever source is not genuine eye tracking
            if (_activeProvider != null &&
                _activeProvider.Provenance != GazeProvenance.EyeTracking_OpenXR &&
                _activeProvider.Provenance != GazeProvenance.EyeTracking_VendorSDK)
            {
                var origColor = GUI.color;
                GUI.color = new Color(1f, 0.8f, 0.2f, 0.95f);
                GUI.Box(new Rect(10, 10, 360, 48), $"GAZE TRACKING STATUS: [{_activeProvider.Provenance}]\n(Simulated/Fallback: NOT genuine eye tracking)");
                GUI.color = origColor;
            }
        }

        private void OnDisable()
        {
            if (_isTrialActive)
            {
                EndTrial(TrialOutcomeInfo.Empty);
            }
        }

        private void OnDestroy()
        {
            _activeProvider?.Shutdown();
            _activeProvider = null;
        }
    }
}
