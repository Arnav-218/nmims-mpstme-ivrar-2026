using System;
using System.Collections;
using System.IO;
using NUnit.Framework;
using UnityEngine;
using UnityEngine.TestTools;
using IVRAR.CybersecurityVR;

namespace IVRAR.CybersecurityVR.Tests
{
    [TestFixture]
    public class SimulatedTrialPlayModeTests
    {
        private GameObject _environmentObj;
        private EyeGazeAttentionTracker _tracker;
        private MockPhishingSimulationManager _mockManager;
        private EyeGazeScenarioBridge _bridge;
        private string _testExportPath;

        [UnitySetUp]
        public IEnumerator SetUp()
        {
            _testExportPath = Path.Combine(Application.temporaryCachePath, "PlayModeTest_" + Guid.NewGuid().ToString("N"));
            Directory.CreateDirectory(_testExportPath);

            _environmentObj = new GameObject("TestEnvironment");

            // Camera
            var camObj = new GameObject("TestCamera");
            camObj.transform.SetParent(_environmentObj.transform);
            camObj.transform.position = Vector3.zero;
            camObj.transform.rotation = Quaternion.identity;
            var cam = camObj.AddComponent<Camera>();
            camObj.tag = "MainCamera";

            // Email stimulus
            var stimulusObj = new GameObject("StimulusBuilder");
            stimulusObj.transform.SetParent(_environmentObj.transform);
            var builder = stimulusObj.AddComponent<TestEmailStimulusBuilder>();
            builder.BuildStimulus();

            // Tracker
            var trackerObj = new GameObject("Tracker");
            trackerObj.transform.SetParent(_environmentObj.transform);
            _tracker = trackerObj.AddComponent<EyeGazeAttentionTracker>();

            // Configure tracker for scripted simulation
            _tracker.SetPolicy(TrackerPolicy.SimulatorOnly);

            // Scripted sequence
            var seq = ScriptableObject.CreateInstance<ScriptedGazeSequence>();
            seq.randomSeed = 12345;
            seq.steps.Add(new ScriptedGazeStep("sender_header", 0.25, noiseDegrees: 0.05f));
            seq.steps.Add(new ScriptedGazeStep("sender_domain", 0.30, noiseDegrees: 0.05f));
            seq.steps.Add(new ScriptedGazeStep("hyperlink_target", 0.35, noiseDegrees: 0.05f));
            seq.steps.Add(new ScriptedGazeStep("email_body", 0.30, noiseDegrees: 0.05f));

            _tracker.SetScriptedSequence(seq);

            // Bridge & Mock Manager
            _bridge = trackerObj.AddComponent<EyeGazeScenarioBridge>();
            _bridge.SetParticipant("SYNTH-TEST01", "S_PLAYMODE", "VR_Immersive");

            _mockManager = trackerObj.AddComponent<MockPhishingSimulationManager>();

            yield return null;
        }

        [UnityTearDown]
        public IEnumerator TearDown()
        {
            if (_environmentObj != null)
            {
                UnityEngine.Object.Destroy(_environmentObj);
            }

            if (Directory.Exists(_testExportPath))
            {
                try
                {
                    Directory.Delete(_testExportPath, true);
                }
                catch { }
            }

            yield return null;
        }

        [UnityTest]
        public IEnumerator Test_ScriptedSimulatedTrial_GeneratesMetricsAndCsv()
        {
            // 1. Begin trial via mock manager
            _mockManager.TriggerTrialStart("T01", "SCENARIO_PHISH_01");
            Assert.IsTrue(_tracker.IsTrialActive, "Trial must be active after trigger");
            Assert.AreEqual(GazeProvenance.Simulated_Scripted, _tracker.CurrentProvenance);

            // 2. Allow simulated scripted sequence to play across ~1.3 seconds
            float elapsed = 0f;
            while (elapsed < 1.4f)
            {
                elapsed += Time.deltaTime;
                yield return null;
            }

            // 3. End trial with a correct report outcome
            _mockManager.TriggerTrialEnd(PhishingTrialOutcome.CorrectReport, 1350.0, "LEVER_FLAG_PHISH", "User noticed suspicious domain");
            Assert.IsFalse(_tracker.IsTrialActive, "Trial must be inactive after EndTrial");

            // 4. Verify trial summary
            var summary = _tracker.LastTrialSummary;
            Assert.IsNotNull(summary, "Trial summary must be available");
            Assert.AreEqual("SYNTH-TEST01", summary.context.participantPseudoId);
            Assert.AreEqual(GazeProvenance.Simulated_Scripted, summary.provenance);
            Assert.IsTrue(summary.isSynthetic, "Simulated data must be flagged as synthetic");
            Assert.AreEqual(PhishingTrialOutcome.CorrectReport, summary.outcome);
            Assert.Greater(summary.totalFixationCount, 0, "Must detect fixations during scripted run");
            Assert.Greater(summary.tTotalDwellMs, 500.0, "Must accumulate significant stimulus dwell");

            // Diagnostic dwell should be > 0 (sender_header, sender_domain, hyperlink_target were all fixated)
            Assert.Greater(summary.tDiagnosticDwellMs, 200.0);
            Assert.Greater(summary.rInspect, 0.0f);
            Assert.LessOrEqual(summary.rInspect, 1.0f);
            Assert.AreEqual("OK", summary.rInspectFlag);
        }
    }
}
