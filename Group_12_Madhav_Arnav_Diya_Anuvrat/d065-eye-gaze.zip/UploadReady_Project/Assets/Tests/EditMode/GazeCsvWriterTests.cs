using System;
using System.IO;
using NUnit.Framework;
using UnityEngine;
using IVRAR.CybersecurityVR;

namespace IVRAR.CybersecurityVR.Tests
{
    [TestFixture]
    public class GazeCsvWriterTests
    {
        private string _testTempDir;

        [SetUp]
        public void SetUp()
        {
            _testTempDir = Path.Combine(Application.temporaryCachePath, "GazeCsvWriterTests_" + Guid.NewGuid().ToString("N"));
            if (Directory.Exists(_testTempDir))
            {
                Directory.Delete(_testTempDir, true);
            }
            Directory.CreateDirectory(_testTempDir);
        }

        [TearDown]
        public void TearDown()
        {
            if (Directory.Exists(_testTempDir))
            {
                try
                {
                    Directory.Delete(_testTempDir, true);
                }
                catch { }
            }
        }

        [Test]
        public void Test_RFC4180_Escaping()
        {
            // Plain string: unchanged
            Assert.AreEqual("simple_text", GazeCsvWriter.EscapeCsvField("simple_text"));

            // String containing comma: quoted
            Assert.AreEqual("\"hello, world\"", GazeCsvWriter.EscapeCsvField("hello, world"));

            // String containing quote: quote doubled and enclosed
            Assert.AreEqual("\"say \"\"hello\"\" now\"", GazeCsvWriter.EscapeCsvField("say \"hello\" now"));

            // String containing newline: quoted
            Assert.AreEqual("\"line1\nline2\"", GazeCsvWriter.EscapeCsvField("line1\nline2"));
        }

        [Test]
        public void Test_InvariantCulture_Numbers()
        {
            float f = 12.3456f;
            double d = 98.7654;
            float nan = float.NaN;

            Assert.AreEqual("12.3456", GazeCsvWriter.FormatFloat(f, "F4"));
            Assert.AreEqual("98.7654", GazeCsvWriter.FormatDouble(d, "F4"));
            Assert.AreEqual("NA", GazeCsvWriter.FormatFloat(nan));
        }

        [Test]
        public void Test_Synthetic_Vs_Real_Directory_Separation()
        {
            // Real session directory
            string realDir = GazeCsvWriter.GetSessionDirectory("SESSION_01", isSynthetic: false, _testTempDir);
            Assert.IsTrue(realDir.Contains("EyeGazeData"), "Real session directory must be under EyeGazeData");
            Assert.IsFalse(realDir.Contains("EyeGazeData_Synthetic"), "Real data must NOT be in EyeGazeData_Synthetic");

            // Synthetic session directory
            string synthDir = GazeCsvWriter.GetSessionDirectory("SESSION_02", isSynthetic: true, _testTempDir);
            Assert.IsTrue(synthDir.Contains("EyeGazeData_Synthetic"), "Synthetic data MUST be in EyeGazeData_Synthetic");
        }

        [Test]
        public void Test_WriteTrialSummary_And_CompanionJson()
        {
            var summary = new GazeTrialSummary
            {
                schemaVersion = "1.0.0",
                context = new TrialContext("SYNTH-P01", "S_TEST", "T01", "SCENARIO_TEST", "VR_Immersive"),
                provenance = GazeProvenance.Simulated_Scripted,
                inputSourceName = "Simulated Scripted Provider",
                isSynthetic = true,
                startUtcIso8601 = DateTime.UtcNow.ToString("o"),
                endUtcIso8601 = DateTime.UtcNow.ToString("o"),
                totalObservationTimeMs = 4000.0,
                validTrackingTimeMs = 3800.0,
                trackingLossTimeMs = 200.0,
                bridgedGapTimeMs = 50.0,
                trackingValidityRatio = 0.95f,
                totalSampleCount = 360,
                estimatedSamplingRateHz = 90.0,
                totalFixationCount = 4,
                meanFixationDurationMs = 450.0,
                dwellMode = DwellMode.FixationBased,
                tSenderHeaderMs = 500.0,
                tSenderDomainMs = 600.0,
                tHyperlinkTargetMs = 800.0,
                tSecurityBadgeMs = 200.0,
                tSubjectLineMs = 400.0,
                tEmailBodyMs = 1000.0,
                tTotalDwellMs = 3500.0,
                tDiagnosticDwellMs = 1900.0,
                rInspect = 0.5429f,
                rInspectFlag = "OK",
                rInspectOverTTotal = 0.4750f,
                includeSecurityBadgeInDiagnostic = false,
                aoiScanSequence = "sender_hdr -> sender_dom -> hyperlink -> body",
                outcome = PhishingTrialOutcome.CorrectReport,
                outcomeAvailable = true,
                responseTimeMs = 3850.0
            };

            bool successSummary = GazeCsvWriter.WriteTrialSummary(summary, _testTempDir);
            Assert.IsTrue(successSummary, "Writing trial summary CSV must succeed");

            bool successMetadata = GazeCsvWriter.WriteSessionMetadata(
                summary.context,
                summary.provenance,
                summary.inputSourceName,
                FixationDetector.Settings.Default,
                GazeMetricsAccumulator.Settings.Default,
                _testTempDir
            );
            Assert.IsTrue(successMetadata, "Writing companion JSON metadata must succeed");

            string expectedDir = Path.Combine(_testTempDir, "EyeGazeData_Synthetic", "S_TEST");
            string summaryPath = Path.Combine(expectedDir, "trial_summary.csv");
            string metadataPath = Path.Combine(expectedDir, "session_metadata.json");

            Assert.IsTrue(File.Exists(summaryPath), "trial_summary.csv must exist in synthetic folder");
            Assert.IsTrue(File.Exists(metadataPath), "session_metadata.json must exist in synthetic folder");

            string summaryContent = File.ReadAllText(summaryPath);
            Assert.IsTrue(summaryContent.Contains("SYNTH-P01"), "Summary must contain participant pseudonym");
            Assert.IsTrue(summaryContent.Contains("Simulated_Scripted"), "Summary must contain provenance");
            Assert.IsTrue(summaryContent.Contains("0.5429"), "Summary must contain formatted R_inspect");

            string jsonContent = File.ReadAllText(metadataPath);
            Assert.IsTrue(jsonContent.Contains("\"schemaVersion\": \"1.0.0\""));
            Assert.IsTrue(jsonContent.Contains("\"isSynthetic\": true"));
        }
    }
}
