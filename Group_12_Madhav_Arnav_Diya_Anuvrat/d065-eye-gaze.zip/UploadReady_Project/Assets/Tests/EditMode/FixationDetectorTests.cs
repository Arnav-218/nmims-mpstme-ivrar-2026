using System;
using NUnit.Framework;
using UnityEngine;
using IVRAR.CybersecurityVR;

namespace IVRAR.CybersecurityVR.Tests
{
    [TestFixture]
    public class FixationDetectorTests
    {
        private FixationDetector _detector;
        private FixationDetector.Settings _settings;

        [SetUp]
        public void SetUp()
        {
            _settings = FixationDetector.Settings.Default;
            _settings.minFixationDurationMs = 150.0;
            _settings.maxDispersionDegrees = 1.0f;
            _settings.saccadeVelocityThresholdDegPerSec = 300.0f;
            _settings.maxGapToleranceMs = 75.0;
            _settings.minValidSampleRatioInFixation = 0.80f;
            _detector = new FixationDetector(_settings);
        }

        [Test]
        public void Test_149ms_vs_150ms_Boundary()
        {
            // At 90 Hz (~11.11 ms interval):
            // 14 samples from t=0.000 to t=0.1444 (144.4 ms < 150 ms)
            // A break sample (exceeding dispersion) at t=0.150
            Vector3 origin = Vector3.zero;
            Vector3 targetDir = Vector3.forward;

            // Feed samples for exactly 140 ms (t=0.000 to t=0.140)
            for (int i = 0; i <= 14; i++)
            {
                double t = i * 0.010; // 0.000 to 0.140 s (140 ms)
                var sample = new GazeSample(t, origin, targetDir, true, 1f, GazeProvenance.SyntheticTest, "Test");
                bool fix = _detector.ProcessSample(sample, AOIType.EmailBody, "body", out _);
                Assert.IsFalse(fix, "Should not emit fixation during stable cluster below 150 ms");
            }

            // Next sample breaks dispersion at t=0.149 (149 ms elapsed)
            Vector3 breakDir = Quaternion.Euler(0, 5f, 0) * targetDir;
            var breakSample = new GazeSample(0.149, origin, breakDir, true, 1f, GazeProvenance.SyntheticTest, "Test");
            bool emittedUnder150 = _detector.ProcessSample(breakSample, AOIType.IrrelevantBackground, "bg", out var fixUnder);
            Assert.IsFalse(emittedUnder150, "A cluster lasting 149 ms must NOT emit a fixation when broken");

            // Reset and test >= 150 ms
            _detector.Reset();
            // Feed samples from t=0.000 to t=0.160 s (160 ms >= 150 ms)
            for (int i = 0; i <= 16; i++)
            {
                double t = i * 0.010;
                var sample = new GazeSample(t, origin, targetDir, true, 1f, GazeProvenance.SyntheticTest, "Test");
                _detector.ProcessSample(sample, AOIType.SenderHeader, "header", out _);
            }

            // Break dispersion at t=0.170 s
            var breakSample2 = new GazeSample(0.170, origin, breakDir, true, 1f, GazeProvenance.SyntheticTest, "Test");
            bool emittedOver150 = _detector.ProcessSample(breakSample2, AOIType.IrrelevantBackground, "bg", out var fixOver);

            Assert.IsTrue(emittedOver150, "A cluster lasting >= 150 ms must emit a confirmed fixation when broken");
            Assert.AreEqual(AOIType.SenderHeader, fixOver.assignedAoiType);
            Assert.AreEqual("header", fixOver.assignedAoiId);
            Assert.GreaterOrEqual(fixOver.durationMs, 150.0);
        }

        [Test]
        public void Test_Dispersion_Boundary()
        {
            Vector3 origin = Vector3.zero;
            Vector3 baseDir = Vector3.forward;

            // Start window at t=0
            var s0 = new GazeSample(0.0, origin, baseDir, true, 1f, GazeProvenance.SyntheticTest, "Test");
            _detector.ProcessSample(s0, AOIType.SenderDomain, "domain", out _);

            // Add samples slightly offset within 0.8 degrees (< 1.0 degree threshold)
            for (int i = 1; i <= 18; i++)
            {
                double t = i * 0.010;
                Vector3 dir = Quaternion.Euler(0.4f * Mathf.Sin(i), 0.4f * Mathf.Cos(i), 0) * baseDir;
                var sample = new GazeSample(t, origin, dir, true, 1f, GazeProvenance.SyntheticTest, "Test");
                bool emitted = _detector.ProcessSample(sample, AOIType.SenderDomain, "domain", out _);
                Assert.IsFalse(emitted, "Window should continue expanding while dispersion <= 1.0 deg");
            }

            // Sample exceeding dispersion threshold (1.5 degrees) at t=0.200s
            Vector3 exceedDir = Quaternion.Euler(0, 1.5f, 0) * baseDir;
            var exceedSample = new GazeSample(0.200, origin, exceedDir, true, 1f, GazeProvenance.SyntheticTest, "Test");
            bool finalized = _detector.ProcessSample(exceedSample, AOIType.EmailBody, "body", out var completed);

            Assert.IsTrue(finalized, "Exceeding dispersion threshold must finalize the prior fixation");
            Assert.AreEqual("domain", completed.assignedAoiId);
            Assert.LessOrEqual(completed.maxDispersionDegrees, 1.01f, "Finalized fixation dispersion must be within threshold");
        }

        [Test]
        public void Test_Gap_Bridged_Vs_Not()
        {
            Vector3 origin = Vector3.zero;
            Vector3 dir = Vector3.forward;

            // Feed 100 ms of valid samples (t=0.000 to t=0.100)
            for (int i = 0; i <= 10; i++)
            {
                _detector.ProcessSample(new GazeSample(i * 0.010, origin, dir, true, 1f, GazeProvenance.SyntheticTest, "Test"),
                    AOIType.HyperlinkTarget, "link", out _);
            }

            // Inject 50 ms gap (invalid sample at t=0.150; 50 ms gap <= 75 ms tolerance)
            _detector.ProcessSample(new GazeSample(0.150, origin, dir, false, float.NaN, GazeProvenance.SyntheticTest, "Test"),
                AOIType.IrrelevantBackground, "bg", out _);

            // Resume valid samples from t=0.160 to t=0.250 (another 90 ms)
            for (int i = 16; i <= 25; i++)
            {
                _detector.ProcessSample(new GazeSample(i * 0.010, origin, dir, true, 1f, GazeProvenance.SyntheticTest, "Test"),
                    AOIType.HyperlinkTarget, "link", out _);
            }

            // Finalize at trial end
            bool finalized = _detector.FinalizeOpenFixation(out var fix);
            Assert.IsTrue(finalized, "Fixation with bridged gap should finalize successfully");
            Assert.GreaterOrEqual(fix.bridgedGapMs, 40.0, "Bridged gap time must be recorded");
            // Gaze duration must NOT include bridged gap time
            double totalRawMs = (0.250 - 0.000) * 1000.0;
            Assert.Less(fix.durationMs, totalRawMs, "Fixation net duration must exclude bridged gap time");

            // Now test gap > 75 ms (e.g. 100 ms gap)
            _detector.Reset();
            for (int i = 0; i <= 10; i++)
            {
                _detector.ProcessSample(new GazeSample(i * 0.010, origin, dir, true, 1f, GazeProvenance.SyntheticTest, "Test"),
                    AOIType.HyperlinkTarget, "link", out _);
            }

            // 100 ms gap (> 75 ms maxGapToleranceMs)
            bool brokenEmitted = _detector.ProcessSample(new GazeSample(0.200, origin, dir, false, float.NaN, GazeProvenance.SyntheticTest, "Test"),
                AOIType.IrrelevantBackground, "bg", out var brokenFix);

            // Because the prior window was only 100 ms (< 150 ms minFixationDuration), it was discarded
            Assert.IsFalse(brokenEmitted, "Prior window under 150 ms broken by long gap must be discarded");
        }

        [Test]
        public void Test_Saccade_Velocity_Rejection()
        {
            Vector3 origin = Vector3.zero;
            Vector3 dir1 = Vector3.forward;

            // Establish fixation on sender domain for 200 ms
            for (int i = 0; i <= 20; i++)
            {
                _detector.ProcessSample(new GazeSample(i * 0.010, origin, dir1, true, 1f, GazeProvenance.SyntheticTest, "Test"),
                    AOIType.SenderDomain, "domain", out _);
            }

            // Next sample 10 ms later rotates by 10 degrees -> 1000 deg/sec (> 300 deg/sec saccade threshold)
            Vector3 saccadeDir = Quaternion.Euler(0, 10f, 0) * dir1;
            bool saccadeDetected = _detector.ProcessSample(new GazeSample(0.210, origin, saccadeDir, true, 1f, GazeProvenance.SyntheticTest, "Test"),
                AOIType.EmailBody, "body", out var fixBeforeSaccade);

            Assert.IsTrue(saccadeDetected, "Saccade gate must finalize prior fixation");
            Assert.AreEqual("domain", fixBeforeSaccade.assignedAoiId);
            Assert.AreEqual(AOIType.SenderDomain, fixBeforeSaccade.assignedAoiType);
        }

        [Test]
        [TestCase(30)]
        [TestCase(72)]
        [TestCase(90)]
        [TestCase(120)]
        public void Test_SamplingRate_Equivalence(int hz)
        {
            _detector.Reset();
            Vector3 origin = Vector3.zero;
            Vector3 dir = Vector3.forward;

            double intervalSec = 1.0 / hz;
            double targetDurationSec = 0.300; // 300 ms stable gaze
            int sampleCount = (int)(targetDurationSec / intervalSec);

            for (int i = 0; i < sampleCount; i++)
            {
                double t = i * intervalSec;
                _detector.ProcessSample(new GazeSample(t, origin, dir, true, 1f, GazeProvenance.SyntheticTest, "Test"),
                    AOIType.SecurityBadge, "badge", out _);
            }

            bool finalized = _detector.FinalizeOpenFixation(out var fix);
            Assert.IsTrue(finalized, $"Must detect fixation at {hz} Hz");
            Assert.AreEqual("badge", fix.assignedAoiId);
            Assert.GreaterOrEqual(fix.durationMs, 250.0);
        }
    }
}
