using System;
using NUnit.Framework;
using UnityEngine;
using IVRAR.CybersecurityVR;

namespace IVRAR.CybersecurityVR.Tests
{
    [TestFixture]
    public class TrackerLifecycleTests
    {
        private GameObject _trackerObj;
        private EyeGazeAttentionTracker _tracker;

        [SetUp]
        public void SetUp()
        {
            _trackerObj = new GameObject("TestTrackerObject");
            _tracker = _trackerObj.AddComponent<EyeGazeAttentionTracker>();
        }

        [TearDown]
        public void TearDown()
        {
            if (_trackerObj != null)
            {
                UnityEngine.Object.DestroyImmediate(_trackerObj);
            }
        }

        [Test]
        public void Test_Double_BeginTrial_HandledSafely()
        {
            _tracker.SetPolicy(TrackerPolicy.SimulatorOnly);

            var ctx1 = new TrialContext("P01", "S01", "T01", "SCENARIO_01");
            var ctx2 = new TrialContext("P01", "S01", "T02", "SCENARIO_02");

            _tracker.BeginTrial(ctx1);
            Assert.IsTrue(_tracker.IsTrialActive);

            // Calling BeginTrial again without calling EndTrial first
            Assert.DoesNotThrow(() => _tracker.BeginTrial(ctx2));
            Assert.IsTrue(_tracker.IsTrialActive);

            _tracker.EndTrial(TrialOutcomeInfo.Empty);
            Assert.IsFalse(_tracker.IsTrialActive);
        }

        [Test]
        public void Test_EndTrial_Without_Begin_HandledSafely()
        {
            _tracker.SetPolicy(TrackerPolicy.SimulatorOnly);

            Assert.IsFalse(_tracker.IsTrialActive);
            // Must not throw NRE or crash
            Assert.DoesNotThrow(() => _tracker.EndTrial(TrialOutcomeInfo.Empty));
            Assert.IsFalse(_tracker.IsTrialActive);
        }

        [Test]
        public void Test_AbortTrial_Records_Reason()
        {
            _tracker.SetPolicy(TrackerPolicy.SimulatorOnly);

            var ctx = new TrialContext("P03", "S01", "T03", "SCENARIO_03");
            _tracker.BeginTrial(ctx);
            Assert.IsTrue(_tracker.IsTrialActive);

            _tracker.AbortTrial("ParticipantRequestedBreak");
            Assert.IsFalse(_tracker.IsTrialActive);

            var summary = _tracker.LastTrialSummary;
            Assert.IsNotNull(summary);
            Assert.AreEqual("ParticipantRequestedBreak", summary.abortReason);
        }

        [Test]
        public void Test_RequireRealEyeTracking_Policy_Enforcement()
        {
            // In unit test environment without real OpenXR hardware,
            // RequireRealEyeTracking must refuse to initialize fallback/simulator
            _tracker.SetPolicy(TrackerPolicy.RequireRealEyeTracking);

            Assert.IsFalse(_tracker.IsTracking, "Real eye tracking should not be falsely reported as available");

            var ctx = new TrialContext("P04", "S01", "T04", "SCENARIO_04");
            _tracker.BeginTrial(ctx);
            _tracker.EndTrial(TrialOutcomeInfo.Empty);

            // Export must be refused when policy is RequireRealEyeTracking and real hardware is absent
            bool exported = _tracker.ExportTrial();
            Assert.IsFalse(exported, "Export must be blocked when RequireRealEyeTracking policy is violated");
        }
    }
}
