using System;
using NUnit.Framework;
using UnityEngine;
using IVRAR.CybersecurityVR;

namespace IVRAR.CybersecurityVR.Tests
{
    [TestFixture]
    public class GazeMetricsAccumulatorTests
    {
        private GazeMetricsAccumulator _accumulator;
        private GazeMetricsAccumulator.Settings _settings;

        [SetUp]
        public void SetUp()
        {
            _settings = GazeMetricsAccumulator.Settings.Default;
            _settings.minTrackingValidityRatio = 0.50f;
            _settings.includeSecurityBadgeInDiagnostic = false;
            _settings.primaryDwellMode = DwellMode.FixationBased;
            _accumulator = new GazeMetricsAccumulator(_settings);
        }

        [Test]
        public void Test_RInspect_Calculation_Normal()
        {
            var ctx = new TrialContext("P01", "S01", "T01", "SCENARIO_01");
            _accumulator.InitializeTrial(ctx, GazeProvenance.SyntheticTest, "Synthetic", 0.0);

            // Feed valid samples spanning 5.0 seconds
            for (int i = 0; i <= 500; i++)
            {
                double t = i * 0.010;
                _accumulator.AccumulateSample(new GazeSample(t, Vector3.zero, Vector3.forward, true, 1f, GazeProvenance.SyntheticTest, "Test"),
                    AOIType.EmailBody, "body");
            }

            // Ingest fixations:
            // Diagnostic: SenderHeader (500ms), SenderDomain (500ms), HyperlinkTarget (1000ms) = 2000ms
            _accumulator.AccumulateFixation(new FixationRecord(1, 0.5, 1.0, Vector3.zero, Vector3.forward, AOIType.SenderHeader, "sender_hdr", 50, 0, 0.5f));
            _accumulator.AccumulateFixation(new FixationRecord(2, 1.2, 1.7, Vector3.zero, Vector3.forward, AOIType.SenderDomain, "sender_dom", 50, 0, 0.4f));
            _accumulator.AccumulateFixation(new FixationRecord(3, 2.0, 3.0, Vector3.zero, Vector3.forward, AOIType.HyperlinkTarget, "link", 100, 0, 0.6f));

            // Non-diagnostic: SubjectLine (500ms), EmailBody (1500ms) = 2000ms
            _accumulator.AccumulateFixation(new FixationRecord(4, 3.1, 3.6, Vector3.zero, Vector3.forward, AOIType.SubjectLine, "subject", 50, 0, 0.3f));
            _accumulator.AccumulateFixation(new FixationRecord(5, 3.5, 5.0, Vector3.zero, Vector3.forward, AOIType.EmailBody, "body", 150, 0, 0.5f));

            var summary = _accumulator.FinalizeTrial(5.0, new TrialOutcomeInfo(PhishingTrialOutcome.CorrectReport, 4800.0));

            // Total dwell = 2000 (diag) + 2000 (non-diag) = 4000 ms
            Assert.AreEqual(4000.0, summary.tTotalDwellMs, 1.0);
            Assert.AreEqual(2000.0, summary.tDiagnosticDwellMs, 1.0);

            // R_inspect = 2000 / 4000 = 0.5000
            Assert.AreEqual(0.50f, summary.rInspect, 0.001f);
            Assert.AreEqual("OK", summary.rInspectFlag);
            Assert.AreEqual(0.40f, summary.rInspectOverTTotal, 0.001f); // 2000ms / 5000ms total observation
        }

        [Test]
        public void Test_RInspect_Zero_Dwell_Produces_NaN_And_Flag()
        {
            var ctx = new TrialContext("P02", "S01", "T02", "SCENARIO_02");
            _accumulator.InitializeTrial(ctx, GazeProvenance.SyntheticTest, "Synthetic", 0.0);

            // Feed samples hitting only IrrelevantBackground (no stimulus dwell)
            for (int i = 0; i <= 200; i++)
            {
                double t = i * 0.010;
                _accumulator.AccumulateSample(new GazeSample(t, Vector3.zero, Vector3.forward, true, 1f, GazeProvenance.SyntheticTest, "Test"),
                    AOIType.IrrelevantBackground, "bg");
            }

            var summary = _accumulator.FinalizeTrial(2.0, TrialOutcomeInfo.Empty);

            Assert.AreEqual(0.0, summary.tTotalDwellMs);
            Assert.IsTrue(float.IsNaN(summary.rInspect), "R_inspect must be NaN when total dwell is zero (never 0/0 or Infinity)");
            Assert.AreEqual("NA_NO_DWELL", summary.rInspectFlag);
        }

        [Test]
        public void Test_RInspect_Low_Validity_Flag()
        {
            var ctx = new TrialContext("P03", "S01", "T03", "SCENARIO_03");
            _accumulator.InitializeTrial(ctx, GazeProvenance.SyntheticTest, "Synthetic", 0.0);

            // 1.0s valid samples, 4.0s invalid samples -> 20% validity ratio (< 50% minTrackingValidityRatio)
            for (int i = 0; i <= 100; i++)
            {
                _accumulator.AccumulateSample(new GazeSample(i * 0.010, Vector3.zero, Vector3.forward, true, 1f, GazeProvenance.SyntheticTest, "Test"),
                    AOIType.SenderHeader, "hdr");
            }
            for (int i = 101; i <= 500; i++)
            {
                _accumulator.AccumulateSample(new GazeSample(i * 0.010, Vector3.zero, Vector3.forward, false, float.NaN, GazeProvenance.SyntheticTest, "Test"),
                    AOIType.IrrelevantBackground, "bg");
            }

            _accumulator.AccumulateFixation(new FixationRecord(1, 0.1, 0.6, Vector3.zero, Vector3.forward, AOIType.SenderHeader, "hdr", 50, 0, 0.5f));

            var summary = _accumulator.FinalizeTrial(5.0, TrialOutcomeInfo.Empty);

            Assert.Less(summary.trackingValidityRatio, 0.50f);
            Assert.AreEqual("LOW_VALIDITY", summary.rInspectFlag, "Tracking validity below threshold must set flag to LOW_VALIDITY");
            Assert.IsFalse(float.IsNaN(summary.rInspect), "R_inspect is still calculated when dwell exists");
        }

        [Test]
        public void Test_RInspect_Only_Diagnostic_Vs_NonDiagnostic()
        {
            // Case 1: 100% Diagnostic
            var ctx = new TrialContext("P04", "S01", "T04", "SCENARIO_04");
            _accumulator.InitializeTrial(ctx, GazeProvenance.SyntheticTest, "Synthetic", 0.0);
            for (int i = 0; i <= 100; i++)
            {
                _accumulator.AccumulateSample(new GazeSample(i * 0.010, Vector3.zero, Vector3.forward, true, 1f, GazeProvenance.SyntheticTest, "Test"),
                    AOIType.HyperlinkTarget, "link");
            }
            _accumulator.AccumulateFixation(new FixationRecord(1, 0.2, 0.8, Vector3.zero, Vector3.forward, AOIType.HyperlinkTarget, "link", 60, 0, 0.5f));
            var summaryDiag = _accumulator.FinalizeTrial(1.0, TrialOutcomeInfo.Empty);
            Assert.AreEqual(1.0f, summaryDiag.rInspect, 0.001f, "100% diagnostic dwell must result in R_inspect = 1.0");

            // Case 2: 100% Non-diagnostic
            _accumulator.Reset();
            _accumulator.InitializeTrial(ctx, GazeProvenance.SyntheticTest, "Synthetic", 0.0);
            for (int i = 0; i <= 100; i++)
            {
                _accumulator.AccumulateSample(new GazeSample(i * 0.010, Vector3.zero, Vector3.forward, true, 1f, GazeProvenance.SyntheticTest, "Test"),
                    AOIType.EmailBody, "body");
            }
            _accumulator.AccumulateFixation(new FixationRecord(1, 0.2, 0.8, Vector3.zero, Vector3.forward, AOIType.EmailBody, "body", 60, 0, 0.5f));
            var summaryNonDiag = _accumulator.FinalizeTrial(1.0, TrialOutcomeInfo.Empty);
            Assert.AreEqual(0.0f, summaryNonDiag.rInspect, 0.001f, "0% diagnostic dwell must result in R_inspect = 0.0");
        }

        [Test]
        public void Test_SecurityBadge_Switch()
        {
            var ctx = new TrialContext("P05", "S01", "T05", "SCENARIO_05");

            // 1. Without SecurityBadge in diagnostic (default)
            _settings.includeSecurityBadgeInDiagnostic = false;
            var accDefault = new GazeMetricsAccumulator(_settings);
            accDefault.InitializeTrial(ctx, GazeProvenance.SyntheticTest, "Synthetic", 0.0);
            for (int i = 0; i <= 100; i++)
            {
                accDefault.AccumulateSample(new GazeSample(i * 0.010, Vector3.zero, Vector3.forward, true, 1f, GazeProvenance.SyntheticTest, "Test"),
                    AOIType.SecurityBadge, "badge");
            }
            accDefault.AccumulateFixation(new FixationRecord(1, 0.2, 0.8, Vector3.zero, Vector3.forward, AOIType.SecurityBadge, "badge", 60, 0, 0.5f));
            var sumDefault = accDefault.FinalizeTrial(1.0, TrialOutcomeInfo.Empty);
            Assert.AreEqual(0.0f, sumDefault.rInspect, 0.001f, "SecurityBadge should not be in diagnostic numerator by default");

            // 2. With SecurityBadge included in diagnostic
            _settings.includeSecurityBadgeInDiagnostic = true;
            var accIncluded = new GazeMetricsAccumulator(_settings);
            accIncluded.InitializeTrial(ctx, GazeProvenance.SyntheticTest, "Synthetic", 0.0);
            for (int i = 0; i <= 100; i++)
            {
                accIncluded.AccumulateSample(new GazeSample(i * 0.010, Vector3.zero, Vector3.forward, true, 1f, GazeProvenance.SyntheticTest, "Test"),
                    AOIType.SecurityBadge, "badge");
            }
            accIncluded.AccumulateFixation(new FixationRecord(1, 0.2, 0.8, Vector3.zero, Vector3.forward, AOIType.SecurityBadge, "badge", 60, 0, 0.5f));
            var sumIncluded = accIncluded.FinalizeTrial(1.0, TrialOutcomeInfo.Empty);
            Assert.AreEqual(1.0f, sumIncluded.rInspect, 0.001f, "SecurityBadge must be in diagnostic numerator when flag is true");
        }

        [Test]
        public void Test_FirstFixationLatency_And_Revisits()
        {
            var ctx = new TrialContext("P06", "S01", "T06", "SCENARIO_06");
            _accumulator.InitializeTrial(ctx, GazeProvenance.SyntheticTest, "Synthetic", 1.0); // trial starts at t=1.0s

            // Fixation 1: SenderHeader starts at t=1.5s (TTFF = 500 ms)
            _accumulator.AccumulateFixation(new FixationRecord(1, 1.5, 2.0, Vector3.zero, Vector3.forward, AOIType.SenderHeader, "hdr", 50, 0, 0.5f));

            // Fixation 2: EmailBody starts at t=2.2s (TTFF = 1200 ms)
            _accumulator.AccumulateFixation(new FixationRecord(2, 2.2, 2.8, Vector3.zero, Vector3.forward, AOIType.EmailBody, "body", 60, 0, 0.5f));

            // Fixation 3: Returns to SenderHeader (revisit!) starts at t=3.0s
            _accumulator.AccumulateFixation(new FixationRecord(3, 3.0, 3.5, Vector3.zero, Vector3.forward, AOIType.SenderHeader, "hdr", 50, 0, 0.5f));

            var summary = _accumulator.FinalizeTrial(4.0, TrialOutcomeInfo.Empty);

            var hdrAoi = summary.aoiSummaries.Find(a => a.aoiId == "hdr");
            Assert.IsNotNull(hdrAoi);
            Assert.AreEqual(500.0, hdrAoi.timeToFirstFixationMs, 1.0);
            Assert.AreEqual(1, hdrAoi.firstFixationOrder);
            Assert.AreEqual(1, hdrAoi.revisitCount);

            var bodyAoi = summary.aoiSummaries.Find(a => a.aoiId == "body");
            Assert.IsNotNull(bodyAoi);
            Assert.AreEqual(1200.0, bodyAoi.timeToFirstFixationMs, 1.0);
            Assert.AreEqual(2, bodyAoi.firstFixationOrder);
            Assert.AreEqual(0, bodyAoi.revisitCount);

            Assert.AreEqual("hdr -> body -> hdr", summary.aoiScanSequence);
        }

        [Test]
        public void Test_ZeroDuration_Observation_DoesNotDivideByZero()
        {
            var ctx = new TrialContext("P07", "S01", "T07", "SCENARIO_07");
            _accumulator.InitializeTrial(ctx, GazeProvenance.SyntheticTest, "Synthetic", 0.0);
            var summary = _accumulator.FinalizeTrial(0.0, TrialOutcomeInfo.Empty);

            Assert.AreEqual(0.0, summary.totalObservationTimeMs);
            Assert.AreEqual(0.0, summary.estimatedSamplingRateHz);
            Assert.AreEqual(0.0f, summary.trackingValidityRatio);
            Assert.AreEqual(0.0f, summary.rInspectOverTTotal);
            Assert.IsTrue(float.IsNaN(summary.rInspect));
        }
    }
}
