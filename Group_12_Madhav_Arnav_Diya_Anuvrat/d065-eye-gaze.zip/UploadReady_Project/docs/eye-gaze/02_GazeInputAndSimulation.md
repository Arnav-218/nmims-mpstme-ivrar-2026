# Gaze Input & Simulation Architecture

**Subsystem Owner:** Person 1 (Eye-Gaze & Attention Tracking Specialist)  
**Target Engine:** Unity 6 (6000.5.3f1)  
**Namespace:** `IVRAR.CybersecurityVR`

---

## 1. Provenance Integrity Model

In academic VR research, distinguishing genuine physiological gaze data from simulated or head-direction approximations is essential for research validity. The subsystem enforces this through an explicit, strongly typed `GazeProvenance` enum embedded in every sample, fixation, and exported CSV row:

| Provenance Enum | Physical Source | Permitted for Analysis? |
|---|---|---|
| `EyeTracking_OpenXR` | Genuine eye tracking via OpenXR standard profile | Yes (Real collection) |
| `EyeTracking_VendorSDK` | Genuine eye tracking via vendor-specific SDK | Yes (Real collection) |
| `HeadDirection_Fallback` | Camera/Head forward vector | Secondary/Comparative only |
| `Simulated_Interactive` | Game-view mouse raycast | Synthetic / Pilot testing only |
| `Simulated_Scripted` | Deterministic scripted timeline | Synthetic / Unit testing only |
| `SyntheticTest` | Directly injected test harness vectors | Unit test validation only |

All synthetic and simulated data are tagged with `is_synthetic = true`, written to `EyeGazeData_Synthetic/`, and will never be mixed with genuine participant sessions.

---

## 2. Gaze Acquisition Providers

### 2.1 OpenXREyeGazeProvider
The genuine eye-tracking provider operates against the Unity Input System without hard vendor SDK bindings:
- **Binding Paths:**
  - `<EyeGaze>/pose`: Evaluates position and rotation in tracking space.
  - `<EyeGaze>/trackingState`: Bitmask verifying rotation (bit 1) and position (bit 0) validity.
  - `<Eyes>/fixationPoint`: Fallback fixation point control.
- **Tracking Space to World Space Transformation:**
  ```csharp
  // Coordinate frame transformation:
  Vector3 worldOrigin = trackingOrigin.TransformPoint(localPose.position);
  Vector3 worldDirection = trackingOrigin.TransformDirection(localPose.rotation * Vector3.forward).normalized;
  ```
- **Validation Checks:**
  - If tracking state indicates untracked, sample is flagged `isValid = false`.
  - Identity/zero poses (`position == Vector3.zero && rotation == Quaternion.identity`) are rejected as uninitialized defaults.
  - Dynamic device connection/disconnection is monitored via `InputSystem.onDeviceChange`.

### 2.2 HeadDirectionFallbackProvider
- Uses `Camera.main.transform.position` and `Camera.main.transform.forward`.
- Explicitly labelled `HeadDirection_Fallback`.
- Confidence is exported as `float.NaN` because eye-level confidence metrics do not exist for head orientation.

### 2.3 SimulatedGazeProvider (Zero External Dependencies)
Operates entirely in-engine without Meta XR Simulator or external packages:
- **Interactive Mode (Mouse):**
  - Reads active Game-view mouse position via `Mouse.current.position.ReadValue()` (guarded to avoid legacy Input exceptions when legacy input is disabled).
  - Raycasts from the reference camera into the 3D scene via `camera.ScreenPointToRay(mousePos)`.
  - **Keyboard Event Simulation:**
    - `Space` or `B` key: Simulates an eye blink (marks samples invalid for duration of hold).
    - `L` key: Toggles tracking loss state.
- **Deterministic Scripted Mode:**
  - Replays a sequence of `ScriptedGazeStep` elements defined in a `ScriptedGazeSequence` asset or created programmatically.
  - Each step defines: target AOI ID, duration (seconds), pseudo-random angular jitter (degrees), and optional dropout intervals.
  - Noise is driven by a deterministic random seed (`System.Random(seed)`) using the Box-Muller transform for realistic Gaussian angular jitter.

---

## 3. Tracker Policy Options

The tracker provides four operating policies:
1. `RequireRealEyeTracking`: Strictly enforces genuine eye tracking. If no hardware is detected, logs an error, disables fallback/simulation, and blocks data export.
2. `PreferRealThenFallback`: Tries OpenXR first; if absent, falls back to `HeadDirection_Fallback` with a prominent on-screen GUI warning.
3. `SimulatorOnly`: Forces interactive mouse or scripted timeline mode.
4. `HeadDirectionOnly`: Forces head forward tracking.
