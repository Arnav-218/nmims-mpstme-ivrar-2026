# Empirical Validation Procedure

**Subsystem Owner:** Person 1 (Eye-Gaze & Attention Tracking Specialist)  
**Target Engine:** Unity 6 (6000.5.3f1)  
**Namespace:** `IVRAR.CybersecurityVR`

---

## 1. Simulation Known-Answer Validation Protocol

Before any hardware or participant testing, the mathematical accuracy of the I-DT detection algorithm and $R_{inspect}$ formula must be validated using known-answer deterministic tests.

### Step 1: Scripted Known-Answer Execution
1. Create a `ScriptedGazeSequence` asset with known target durations:
   - Target 1: `sender_header` (Duration = $0.400\text{ s} = 400\text{ ms}$)
   - Target 2: `sender_domain` (Duration = $0.600\text{ s} = 600\text{ ms}$)
   - Target 3: `hyperlink_target` (Duration = $1.000\text{ s} = 1000\text{ ms}$)
   - Target 4: `email_body` (Duration = $2.000\text{ s} = 2000\text{ ms}$)
   - Total stimulus duration = $4000\text{ ms}$.
   - Expected $T_{diagnostic} = 400 + 600 + 1000 = 2000\text{ ms}$.
   - Expected $T_{total\_dwell} = 4000\text{ ms}$.
   - **Theoretical Known Answer:** $R_{inspect} = 2000 / 4000 = 0.5000$.
2. Run the trial in `SimulatorOnly` mode.
3. Open the resulting `trial_summary.csv` in `EyeGazeData_Synthetic/` and verify:
   - `provenance` equals `Simulated_Scripted`.
   - `is_synthetic` equals `true`.
   - Calculated `r_inspect` is within numerical tolerance ($0.5000 \pm 0.01$).
   - `r_inspect_flag` is `"OK"`.

---

## 2. Hardware Verification Protocol (Physical VR Headset)

When eye-tracking hardware (e.g. Meta Quest Pro, HTC Vive Pro Eye, Apple Vision Pro, or Varjo Aero) is connected, perform the following 7-step empirical validation protocol:

### Step 1: System-Level Eye Calibration
- Prior to launching the Unity application, run the headset operating system's built-in 5-point or 9-point eye calibration tool.
- Ensure the headset fit is snug and interpupillary distance (IPD) is physically adjusted to the user.

### Step 2: Runtime Provenance Check
- Launch the simulation in Unity.
- Look at the on-screen GUI / console:
  - Verify that the active provider is `OpenXR Eye Gaze Provider`.
  - Confirm the yellow "GAZE TRACKING STATUS: [Simulated/Fallback]" warning box is **NOT** displayed.
  - Verify `CurrentProvenance` is `EyeTracking_OpenXR`.

### Step 3: Accuracy and Precision Check (9-Point Target Grid)
- Fixate sequentially on a 9-point calibration verification crosshair grid positioned at $1.2\text{ m}$ distance.
- Verify that the raycast intersection lands squarely within the targeted crosshair collider ($< 1.0^\circ$ visual angle offset).

### Step 4: Sampling Rate Verification
- Verify the `estimated_sampling_rate_hz` in `trial_summary.csv`.
- Confirm it matches the expected hardware frequency (e.g. $72\text{ Hz}$, $90\text{ Hz}$, or $120\text{ Hz}$) with negligible jitter.

### Step 5: Blink and Occlusion Test
- Intentionally blink eyes normally for 5 seconds.
- Verify that:
  - Gaps $\le 75\text{ ms}$ are bridged without fragmenting fixations.
  - Extended eyelid closures ($> 150\text{ ms}$) are correctly classified as tracking loss (`tracking_loss_time_ms`) and do not credit dwell to whatever was behind the eyelids.

### Step 6: Coordinate Transform Verification
- Rotate head while maintaining gaze on a fixed visual target (vestibulo-ocular reflex test).
- Verify that the world-space gaze vector remains locked on the target despite head rotation, confirming tracking-space to world-space transform matrix correctness.

### Step 7: Researcher-Only Pilot Run
- Perform 3 complete mock trials through `MockPhishingSimulationManager`.
- Inspect the generated `trial_summary.csv` and `aoi_metrics.csv` to ensure all columns conform to schema.

---

## 3. Data-Quality Exclusion Criteria (Fixed Prior to Collection)

To protect research integrity and avoid post-hoc bias, the following pre-registered data-quality exclusion thresholds must be enforced:
1. **Low Tracking Validity Exclusion:** Any trial where `tracking_validity_ratio < 0.50` (more than $50\%$ tracking loss) is marked with `r_inspect_flag = "LOW_VALIDITY"` and must be excluded from primary hypothesis testing.
2. **Zero Stimulus Dwell:** Any trial where `r_inspect_flag == "NA_NO_DWELL"` (participant never looked at the email stimulus) cannot evaluate cognitive threat inspection and is treated as a behavioral non-engagement event.
3. **Severe Hardware Desynchronization:** Trials with `estimated_sampling_rate_hz < 30.0` indicate operating system throttling or USB connection drops and must be flagged for exclusion.

> **RESEARCH NOTE:** Statistical hypothesis testing, effect sizes, and longitudinal retention modelling require genuinely collected empirical participant data and belong exclusively to the analysis stage led by Person 4.
