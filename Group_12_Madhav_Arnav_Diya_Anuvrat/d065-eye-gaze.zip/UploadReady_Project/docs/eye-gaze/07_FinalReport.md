# Final Handover Report: Eye-Gaze & Attention Tracking Subsystem

**Subsystem Owner:** Person 1 (Eye-Gaze & Attention Tracking Specialist)  
**Research Context:** "To what extent does an immersive VR phishing simulation improve threat recognition and mitigate cognitive bias compared to standard 2D web-based cybersecurity training across a 14-day retention interval?"  
**Engine:** Unity 6 (6000.5.3f1)  
**Namespace:** `IVRAR.CybersecurityVR`

---

## 1. Architecture Found

- **Engine & Project Baseline:** Unity `6000.5.3f1` using Universal Render Pipeline (URP 17.5.0) and the New Input System (`com.unity.inputsystem@1.19.0`).
- **Active Input Handling:** `activeInputHandler: 1` (New Input System exclusively; legacy input disabled in project settings).
- **Subsystem State at Inception:** No prior C# code existed for the eye-gaze tracking subsystem. `Assets/Scripts/` did not exist. No teammate scripts (`PhishingThreatSimulationManager.cs`, office workstation scenes, or retention scripts) were present in the repository.
- **Packages Present:** Input System (1.19.0), UGUI/TextMeshPro (2.5.0), Test Framework (1.7.0), Core Physics. OpenXR (`com.unity.xr.openxr`), XR Management (`com.unity.xr.management`), and Meta XR Simulator were **not** installed.

---

## 2. Every File Created and Its Role

### 2.1 Core Subsystem Runtime (`Assets/Scripts/`)
- `Assets/Scripts/IVRAR.CybersecurityVR.asmdef`: Assembly definition isolating runtime code and linking `Unity.InputSystem` and `Unity.TextMeshPro`.
- `Assets/Scripts/EyeGazeAttentionTracker.cs`: Central manager MonoBehaviour orchestrating acquisition, non-allocating raycasting, I-DT fixation detection, $R_{inspect}$ calculation, lifecycle state, and CSV exports.

### 2.2 Gaze Acquisition & Simulation (`Assets/Scripts/Gaze/`)
- `GazeSample.cs`: Core `GazeSample` struct, `IGazeSampleProvider` interface, `GazeProvenance` enum, and `TrackerPolicy` enum.
- `OpenXREyeGazeProvider.cs`: Real OpenXR eye tracking provider binding to `<EyeGaze>/pose` and `<EyeGaze>/trackingState` via Unity Input System. Transforms tracking space to world space and validates tracking states.
- `HeadDirectionFallbackProvider.cs`: Fallback provider utilizing camera forward vector, explicitly labelled `HeadDirection_Fallback` (confidence = NaN).
- `ScriptedGazeSequence.cs`: Data structs and ScriptableObject asset defining deterministic gaze timelines with fixed random seeds for repeatable testing.
- `SimulatedGazeProvider.cs`: Zero-dependency simulation provider supporting both Interactive Game-view mouse raycasts (with Space/B blink and L tracking loss simulation) and Scripted timeline playback. Preprocessor-guarded to prevent runtime exceptions when legacy input is disabled.

### 2.3 AOI Detection & Spatial Registry (`Assets/Scripts/Gaze/`)
- `GazeAOITarget.cs`: Component attached to email stimulus objects defining `AOIType`, unique stable ID, and raycast priority.
- `GazeAOIRegistry.cs`: Static $O(1)$ dictionary registry mapping physics colliders to `GazeAOITarget` instances, avoiding `GetComponent` or `Find` in hot paths.
- `GazeAOIColliderFitter.cs`: Tooling component to fit 3D `BoxCollider` instances to `RectTransform` or `TextMeshProUGUI` text bounds.
- `TestEmailStimulusBuilder.cs`: Component generating a 7-element primitive-collider test email stimulus in the scene for immediate testing without teammate workstation assets.

### 2.4 Fixation Detection & Metrics Accumulator (`Assets/Scripts/Gaze/`)
- `FixationRecord.cs`: Data structure recording validated spatial fixations, centroids, dispersion, and assigned AOI.
- `FixationDetector.cs`: Pure C# implementation of the Identification by Dispersion-Threshold (I-DT) algorithm in angular visual space with a saccade velocity gate ($300^\circ/\text{s}$) and gap bridging ($\le 75\text{ms}$).
- `TrialModels.cs`: Experimental data models: `TrialContext`, `TrialOutcomeInfo`, `AOIMetricSummary`, and `GazeTrialSummary`.
- `GazeMetricsAccumulator.cs`: Pure C# engine accumulating per-AOI dwell across two independent modes (`FixationBased` and `RawSample`), computing TTFF, first-fixation order, revisit counts, and the Threat Inspection Ratio ($R_{inspect}$).
- `GazeCsvWriter.cs`: RFC 4180 compliant CSV serializer with invariant-culture numerical formatting, synthetic directory isolation, and companion JSON session metadata generation.

### 2.5 Team Integration & Mocking (`Assets/Scripts/Gaze/`)
- `EyeGazeScenarioBridge.cs`: Adapter listening to scenario manager lifecycle events and invoking tracker API.
- `MockPhishingSimulationManager.cs`: Mock scenario manager providing lifecycle events for testing and serving as a reference for Person 2.

### 2.6 Test Suites (`Assets/Tests/`)
- `Assets/Tests/EditMode/IVRAR.CybersecurityVR.EditModeTests.asmdef`: Assembly definition for EditMode NUnit tests.
- `Assets/Tests/PlayMode/IVRAR.CybersecurityVR.PlayModeTests.asmdef`: Assembly definition for PlayMode integration tests.
- `Assets/Tests/EditMode/FixationDetectorTests.cs`: Boundary tests (149ms vs 150ms), dispersion threshold, gap bridging, saccade velocity rejection, and 30/72/90/120 Hz sampling equivalence.
- `Assets/Tests/EditMode/GazeMetricsAccumulatorTests.cs`: $R_{inspect}$ arithmetic, zero-dwell `NA_NO_DWELL` NaN export, `LOW_VALIDITY` flag, TTFF, and revisit counts.
- `Assets/Tests/EditMode/GazeCsvWriterTests.cs`: RFC 4180 escaping, invariant-culture numbers, synthetic directory isolation, and JSON schema.
- `Assets/Tests/EditMode/TrackerLifecycleTests.cs`: Double `BeginTrial`, `EndTrial` without `Begin`, abort reasons, and `RequireRealEyeTracking` policy enforcement.
- `Assets/Tests/PlayMode/SimulatedTrialPlayModeTests.cs`: Scripted simulation trial against primitive stimulus colliders verifying end-to-end integration.

### 2.7 Documentation Suite (`docs/`)
- `docs/EYE_GAZE_ATTENTION_TRACKING_SETUP.md`: Complete setup and integration guide.
- `docs/eye-gaze/00_ProjectAudit.md`: Audit of project packages, engine version, and input system.
- `docs/eye-gaze/01_Architecture.md`: Architectural decoupling and component flow.
- `docs/eye-gaze/02_GazeInputAndSimulation.md`: Gaze acquisition mechanics, simulation modes, and provenance model.
- `docs/eye-gaze/03_MetricsDefinitions.md`: $R_{inspect}$ formula, worked illustrative examples, and flags.
- `docs/eye-gaze/04_CsvSchema.md`: Table column specifications for all exported tables.
- `docs/eye-gaze/05_ValidationProcedure.md`: 7-step hardware verification protocol and pre-registered exclusion criteria.
- `docs/eye-gaze/06_Limitations.md`: Hardware, cognitive, and simulator limitations.
- `docs/eye-gaze/07_FinalReport.md`: Handover summary.

---

## 3. Gaze Provider Path & Package Verification

- **OpenXR Path:** Implemented in `OpenXREyeGazeProvider.cs` via Unity Input System bindings (`<EyeGaze>/pose`, `<EyeGaze>/trackingState`, `<Eyes>/fixationPoint`).
- **Verified Package:** `com.unity.inputsystem@1.19.0` (installed). Verified against package source `InputSystem/Plugins/XR/XRSupport.cs`.
- **Hardware Validation Requirements:**
  - Connecting a physical eye-tracking headset (e.g. Meta Quest Pro, HTC Vive Pro Eye, Apple Vision Pro, Varjo).
  - Adding `com.unity.xr.openxr` and `com.unity.xr.management` via Unity Package Manager.
  - Enabling the OpenXR Eye Gaze Interaction profile (`XR_EXT_eye_gaze_interaction`).
  - Executing the 7-step hardware validation protocol in `05_ValidationProcedure.md`.

---

## 4. Manual Unity Setup Steps

1. **Create User Layer `GazeAOI`:** In `Edit -> Project Settings -> Tags and Layers`, add `GazeAOI` to User Layer 6.
2. **Assign Layer & Colliders to AOI Objects:** Set all email stimulus colliders to layer `GazeAOI` and attach `GazeAOITarget`.
3. **Add Tracker to Scene:** Attach `EyeGazeAttentionTracker` to a GameObject in the scene.
4. **Assign Camera:** Assign the Main Camera to `Reference Camera` on the tracker.

---

## 5. How to Run a Simulation Test and Verify CSV Output

1. Set `Gaze Acquisition Policy` on `EyeGazeAttentionTracker` to `SimulatorOnly`.
2. Set `Simulation Sub Mode` to `InteractiveMouse`.
3. Press **Play** in Unity: move the mouse across the email panel to gaze, press **Space** to blink, and press **L** to toggle tracking loss.
4. Upon trial completion (`EndTrial()`), verify CSV files generated at:
   ```
   <persistentDataPath>/EyeGazeData_Synthetic/<sessionId>/trial_summary.csv
   <persistentDataPath>/EyeGazeData_Synthetic/<sessionId>/aoi_metrics.csv
   <persistentDataPath>/EyeGazeData_Synthetic/<sessionId>/fixations.csv
   <persistentDataPath>/EyeGazeData_Synthetic/<sessionId>/session_metadata.json
   ```

---

## 6. Compilation & Test Results

- **Static Compilation:** All runtime scripts compiled with **0 errors and 0 warnings** using Roslyn compiler against Unity 6 engine binaries and `netstandard 2.1`.
- **Test Execution Status:** **Not run via CLI batchmode** because the Unity Editor is currently open with this project loaded (Unity locks the project database, preventing concurrent batchmode processes).
- **How to Run Tests in Unity Editor:**
  1. In the Editor menu, open **Window -> General -> Test Runner**.
  2. Under the **EditMode** tab, click **Run All** to execute all 18 EditMode test fixtures.
  3. Under the **PlayMode** tab, click **Run All** to execute the PlayMode integration test.

---

## 7. Unresolved Issues & Technical Limitations

- No runtime compiler errors or missing symbols exist.
- Physical eye-tracking validation requires Person 1 to install the `com.unity.xr.openxr` package in the Package Manager and connect a supported headset.
- Covert attention limitation: Fixating an AOI confirms visual inspection but does not guarantee cognitive threat comprehension (refer to `06_Limitations.md`).

---

## 8. Team Coordination Summary

- **Person 2 (Scenario Lifecycle):** Must invoke `BeginTrial(TrialContext)` upon email stimulus presentation and `EndTrial(TrialOutcomeInfo)` upon user decision. Alternatively, connect through `EyeGazeScenarioBridge`.
- **Person 3 (Workstation & UI):** Must set email panel element layers to `GazeAOI`, attach `GazeAOITarget`, and use `GazeAOIColliderFitter` to align trigger `BoxCollider` components.
- **Person 4 (Human Factors & Retention):** Consumes `trial_summary.csv` and `aoi_metrics.csv`. Primary metrics: `r_inspect`, `r_inspect_flag`, `t_sender_domain_ms`, `t_hyperlink_target_ms`, `t_total_dwell_ms`, and `tracking_validity_ratio`.
