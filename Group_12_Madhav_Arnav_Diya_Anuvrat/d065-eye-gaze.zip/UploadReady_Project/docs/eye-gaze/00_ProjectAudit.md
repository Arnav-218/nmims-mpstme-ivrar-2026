# Project Audit: Eye-Gaze & Attention Tracking Subsystem

**Subsystem Owner:** Person 1 (Eye-Gaze & Attention Tracking Specialist)  
**Research Context:** "To what extent does an immersive VR phishing simulation improve threat recognition and mitigate cognitive bias compared to standard 2D web-based cybersecurity training across a 14-day retention interval?"  
**Date:** October 2026  
**Branch:** `feature/eye-gaze-attention-tracker`

---

## 1. Verified Facts (Repository Inspection)

### 1.1 Unity Engine & Environment
- **Project Version:** Unity `6000.5.3f1` (rev `c2eb47b3a2a9`), as verified in `ProjectSettings/ProjectVersion.txt`.
- **Editor Binary:** Unity 6000.5.3f1 64-bit editor runtime.
- **Target Platforms:** Standalone (Windows x86_64), Android (Meta Quest target profile configured with `minSdkVersion: 26`).
- **Scripting Backend:**
  - Android: `IL2CPP` (verified in `ProjectSettings/ProjectSettings.asset:L837`).
  - Standalone: Mono runtime default.
- **Render Pipeline:** Universal Render Pipeline (URP), verified via `Packages/manifest.json` (`com.unity.render-pipelines.universal@17.5.0`) and pipeline assets in `Assets/Settings/` (`PC_RPAsset.asset`, `Mobile_RPAsset.asset`).
- **Active Input Handling:**
  - `com.unity.inputsystem` version `1.19.0` is installed and active (`Packages/manifest.json:L9`, `Packages/packages-lock.json:L110`).
  - `Assets/InputSystem_Actions.inputactions` exists in `Assets/`.
  - Legacy `InputManager.asset` is present with default axis definitions.

### 1.2 XR & Package Inventory
Verified against `Packages/manifest.json` and `Packages/packages-lock.json`:
- `com.unity.inputsystem`: `1.19.0` (installed).
- `com.unity.test-framework`: `1.7.0` (installed, NUnit 2.1.0 backend).
- `com.unity.render-pipelines.universal`: `17.5.0` (installed).
- `com.unity.ugui`: `2.5.0` (installed).
- `com.unity.modules.xr`: `1.0.0` (installed built-in module).
- **Packages NOT currently in `manifest.json`:**
  - `com.unity.xr.management` is **not installed**.
  - `com.unity.xr.openxr` is **not installed**.
  - `com.unity.xr.interaction.toolkit` is **not installed**.
  - No vendor SDKs (`com.meta.xr.sdk.*`, `com.htc.upm.wave.*`) are installed.
  - `Meta XR Simulator` is **not present** (conforms to strict project constraint: no simulator dependency permitted).

### 1.3 Eye-Tracking Hardware & API Capabilities in Current Environment
- In `com.unity.inputsystem@1.19.0` (`InputSystem/Plugins/XR/XRSupport.cs:L191-L376`):
  - Struct `UnityEngine.InputSystem.XR.Eyes` and control `EyesControl` are present, providing `leftEyePosition`, `leftEyeRotation`, `rightEyePosition`, `rightEyeRotation`, `fixationPoint`, `leftEyeOpenAmount`, and `rightEyeOpenAmount`.
  - When OpenXR is installed, the OpenXR Eye Gaze Interaction profile binds to `/user/eyes_ext/input/gaze_ext/pose` and publishes standard eye gaze poses into the Input System.
  - Because `com.unity.xr.openxr` is not yet present in `manifest.json`, direct compilation against OpenXR specific types (e.g. `UnityEngine.XR.OpenXR.Features.Interactions.EyeGazeInteraction`) requires either:
    1. The OpenXR package to be added via Package Manager by Person 1/developer, OR
    2. Input System generic device querying (`InputSystem.GetDevice<InputDevice>()` / control path `/user/eyes_ext/input/gaze_ext/pose` or `EyesControl`), with fallback/unavailability reporting when the provider is absent.
  - **Compliance with Non-Negotiable Rule 1:** We never invent APIs or silently alter `manifest.json`. We implement the OpenXR provider through verified Unity Input System pathways and runtime capability checks, provide graceful reporting of device/runtime availability, and provide exact, step-by-step instructions for installing OpenXR.

### 1.4 Workspace Assets, Scripts, and Scenes
- **Existing Scripts:** None for our subsystem. `Assets/Scripts/` did not exist.
- **Teammate Code:**
  - Person 2's `PhishingThreatSimulationManager.cs` does not yet exist in `Assets/Scripts/`.
  - Person 3's VR office workstation and email spatial UI do not yet exist.
  - Person 4's retention scripts do not exist.
- **Existing Scenes:** Only `Assets/Scenes/SampleScene.unity` (standard URP template scene with camera and directional light).
- **Tags & Layers:**
  - `ProjectSettings/TagManager.asset` contains only built-in layers (0: Default, 1: TransparentFX, 2: Ignore Raycast, 4: Water, 5: UI).
  - The layer `GazeAOI` is **not yet created**.

---

## 2. Architectural Assumptions & Mitigations

| Area | Assumption / Baseline | Mitigation / Safe Design |
|---|---|---|
| **Namespace** | `IVRAR.CybersecurityVR` | Follows standard project brief; isolated to avoid conflicts with teammates. |
| **Teammate Integration** | Person 2's manager may arrive later | Create `EyeGazeScenarioBridge` with clear event hooks and a standalone test mock manager (`MockPhishingSimulationManager`). |
| **Workstation Scene** | Person 3's workstation scene is under development | Provide a self-contained test email scene (`TestPhishingEmailScene.unity`) with primitive colliders matching email components. |
| **Layer Configuration** | `GazeAOI` layer must be added manually in Editor | Tracker script dynamically verifies layer existence via `LayerMask.NameToLayer("GazeAOI")`. If missing, tracker logs a descriptive error and halts without falling back to `Default`. |
| **Simulation Mode** | Developer lacks VR headset / Meta XR Simulator | Build a dual-mode, zero-dependency simulator: (1) Game-view mouse raycast interactive mode, (2) Deterministic scripted replay mode for automated tests and repeatable trials. |
| **Research Integrity** | Strict distinction between real and simulated data | Every single sample, fixation, trial summary, and CSV row contains a strict `GazeProvenance` enum and `is_synthetic` flag. Synthetic data writes to `EyeGazeData_Synthetic/` only. |

---

## 3. Package Verification Matrix

| Target API / Feature | Verified Location | Status | Action Required |
|---|---|---|---|
| `UnityEngine.InputSystem` | `Packages/manifest.json:L9`, `packages-lock.json:L110` | Installed (`1.19.0`) | Use for input handling, mouse simulation, and generic XR device query |
| `UnityEngine.InputSystem.XR.Eyes` | `Library/PackageCache/com.unity.inputsystem@21a28c3a6c83/InputSystem/Plugins/XR/XRSupport.cs:L191` | Installed | Verified struct definition |
| `UnityEngine.InputSystem.XR.EyesControl` | `Library/PackageCache/com.unity.inputsystem@21a28c3a6c83/InputSystem/Plugins/XR/XRSupport.cs:L322` | Installed | Verified control definition |
| `UnityEngine.TestTools` (NUnit) | `Packages/manifest.json:L12`, `packages-lock.json:L191` | Installed (`1.7.0`) | Used for EditMode and PlayMode suites |
| `Physics.RaycastNonAlloc` | Unity Engine Physics Module (`com.unity.modules.physics`) | Built-in | Used with preallocated `RaycastHit[]` buffer |
| OpenXR Eye Gaze Profile | OpenXR specification `XR_EXT_eye_gaze_interaction` | Not installed in project | Document exact steps for Person 1 to install OpenXR package |
