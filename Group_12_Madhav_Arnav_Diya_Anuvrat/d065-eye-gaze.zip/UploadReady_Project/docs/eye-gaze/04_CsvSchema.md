# CSV Schema Documentation

**Subsystem Owner:** Person 1 (Eye-Gaze & Attention Tracking Specialist)  
**Consumer:** Person 4 (Human Factors & Retention Modelling)  
**Target Engine:** Unity 6 (6000.5.3f1)  
**Specification Standard:** RFC 4180 / ISO 8601 UTC / InvariantCulture

---

## 1. Directory Structure

Data files are written to subfolders within the project persistent data path:
- Genuine Sessions: `EyeGazeData/<session_id>/`
- Synthetic / Simulated Sessions: `EyeGazeData_Synthetic/<session_id>/`

Files produced per session:
1. `trial_summary.csv` (One row per completed trial)
2. `aoi_metrics.csv` (One row per AOI per trial)
3. `fixations.csv` (One row per detected fixation)
4. `session_metadata.json` (Companion hardware and threshold parameters)

---

## 2. Table Schemas

### 2.1 trial_summary.csv
Summary of full trial observation, overall tracking quality, and threat inspection metrics.

| Column Name | Type | Example | Description |
|---|---|---|---|
| `schema_version` | String | `1.0.0` | Schema version identifier |
| `participant_pseudo_id` | String | `P01` | Pseudonymous participant identifier (or `SYNTH-01`) |
| `session_id` | String | `S01` | Session identifier |
| `trial_id` | String | `T01` | Unique trial number within session |
| `scenario_id` | String | `SCENARIO_BANK_SPOOF` | Phishing scenario / email stimulus identifier |
| `condition_label` | String | `VR_Immersive` | Experimental condition (`VR_Immersive`, `Web_2D`, etc.) |
| `provenance` | String | `EyeTracking_OpenXR` | Provenance category (`EyeTracking_OpenXR`, `Simulated_Interactive`, etc.) |
| `input_source` | String | `OpenXR Eye Gaze Provider` | Concrete acquisition provider name |
| `is_synthetic` | Boolean | `false` | True if simulated, scripted, or synthetic test data |
| `start_utc_iso8601` | String | `2026-10-23T04:15:30.123Z` | Trial start timestamp in UTC ISO 8601 format |
| `end_utc_iso8601` | String | `2026-10-23T04:15:36.123Z` | Trial end timestamp in UTC ISO 8601 format |
| `t_total_observation_ms` | Float | `6000.00` | Total observation time in milliseconds |
| `valid_tracking_time_ms` | Float | `5700.00` | Duration with valid eye tracking in ms |
| `tracking_loss_time_ms` | Float | `300.00` | Duration of unbridged tracking loss in ms |
| `bridged_gap_time_ms` | Float | `45.00` | Total duration of bridged mini-gaps ($\le 75\text{ms}$) in ms |
| `tracking_validity_ratio` | Float | `0.9500` | Valid tracking time divided by total observation time |
| `total_sample_count` | Integer | `540` | Total sample count ingested |
| `estimated_sampling_rate_hz` | Float | `90.00` | Estimated sampling rate in Hertz |
| `total_fixation_count` | Integer | `8` | Total confirmed fixations during trial |
| `mean_fixation_duration_ms` | Float | `380.50` | Mean fixation duration across all AOIs in ms |
| `dwell_mode` | String | `FixationBased` | Dwell crediting mode (`FixationBased` or `RawSample`) |
| `t_sender_header_ms` | Float | `400.00` | Dwell on SenderHeader in ms |
| `t_sender_domain_ms` | Float | `800.00` | Dwell on SenderDomain in ms |
| `t_hyperlink_target_ms` | Float | `1200.00` | Dwell on HyperlinkTarget in ms |
| `t_security_badge_ms` | Float | `150.00` | Dwell on SecurityBadge in ms |
| `t_subject_line_ms` | Float | `600.00` | Dwell on SubjectLine in ms |
| `t_email_body_ms` | Float | `2000.00` | Dwell on EmailBody in ms |
| `t_total_dwell_ms` | Float | `5150.00` | Sum of dwell across all stimulus AOIs in ms |
| `t_diagnostic_dwell_ms` | Float | `2400.00` | Sum of sender + domain + hyperlink dwell in ms |
| `r_inspect` | Float | `0.4660` | Threat Inspection Ratio ($T_{diagnostic} / T_{total\_dwell}$) |
| `r_inspect_flag` | String | `OK` | Flag (`OK`, `NA_NO_DWELL`, `LOW_VALIDITY`) |
| `r_inspect_over_t_total` | Float | `0.4000` | Diagnostic dwell divided by total observation time |
| `include_security_badge_in_diagnostic` | Boolean | `false` | Whether SecurityBadge is counted in diagnostic numerator |
| `aoi_scan_sequence` | String | `sender_hdr -> sender_dom -> body -> link` | Chronological transition sequence across AOIs |
| `outcome` | String | `CorrectReport` | Behavioral outcome (`CorrectReport`, `MissedThreat`, `FalseAlarm`, `Timeout`) |
| `outcome_available` | Boolean | `true` | Whether behavioral outcome arrived from scenario manager |
| `response_time_ms` | Float | `5850.00` | Time until report lever interaction in ms |
| `abort_reason` | String | `""` | Abort reason if trial was terminated early |

---

### 2.2 aoi_metrics.csv
Per-AOI detailed metrics for fine-grained attention analysis.

| Column Name | Type | Example | Description |
|---|---|---|---|
| `schema_version` | String | `1.0.0` | Schema version |
| `participant_pseudo_id` | String | `P01` | Pseudonym identifier |
| `session_id` | String | `S01` | Session identifier |
| `trial_id` | String | `T01` | Trial identifier |
| `scenario_id` | String | `SCENARIO_BANK_SPOOF` | Scenario identifier |
| `provenance` | String | `EyeTracking_OpenXR` | Provenance label |
| `is_synthetic` | Boolean | `false` | Synthetic flag |
| `aoi_type` | String | `SenderDomain` | Semantic AOI classification enum |
| `aoi_id` | String | `sender_domain_01` | Stable string AOI identifier |
| `is_diagnostic` | Boolean | `true` | Whether considered diagnostic in $R_{inspect}$ |
| `fixation_dwell_ms` | Float | `800.00` | Fixation-based dwell time in ms |
| `fixation_count` | Integer | `2` | Number of fixations resting on this AOI |
| `mean_fixation_duration_ms` | Float | `400.00` | Average fixation duration on this AOI |
| `max_fixation_duration_ms` | Float | `450.00` | Longest single fixation on this AOI |
| `time_to_first_fixation_ms` | Float | `850.00` | Latency from trial start to first fixation (`NA` if never fixated) |
| `first_fixation_order` | Integer | `2` | 1-indexed visit rank (`NA` if never fixated) |
| `revisit_count` | Integer | `1` | Re-fixations after looking away |
| `raw_sample_dwell_ms` | Float | `840.00` | Secondary raw sample hit dwell in ms |
| `raw_sample_count` | Integer | `76` | Total raw samples intersecting AOI |

---

### 2.3 fixations.csv
Individual spatial fixation records detected by the I-DT algorithm.

| Column Name | Type | Example | Description |
|---|---|---|---|
| `schema_version` | String | `1.0.0` | Schema version |
| `participant_pseudo_id` | String | `P01` | Participant pseudonym |
| `session_id` | String | `S01` | Session identifier |
| `trial_id` | String | `T01` | Trial identifier |
| `scenario_id` | String | `SCENARIO_BANK_SPOOF` | Scenario identifier |
| `provenance` | String | `EyeTracking_OpenXR` | Provenance label |
| `is_synthetic` | Boolean | `false` | Synthetic flag |
| `fixation_id` | Integer | `1` | Sequential fixation ID within trial |
| `start_time_seconds` | Double | `0.8500` | Fixation onset timestamp in seconds |
| `end_time_seconds` | Double | `1.2500` | Fixation offset timestamp in seconds |
| `duration_ms` | Float | `400.00` | Net duration excluding bridged gaps in ms |
| `assigned_aoi_type` | String | `SenderDomain` | AOI assigned via majority vote or centroid |
| `assigned_aoi_id` | String | `sender_domain_01` | Stable string identifier of assigned AOI |
| `sample_count` | Integer | `36` | Number of gaze samples within window |
| `bridged_gap_ms` | Float | `0.00` | Bridged mini-gap duration during window |
| `max_dispersion_degrees` | Float | `0.62` | Maximum angular dispersion within window |
| `centroid_origin_x/y/z` | Float | `0.0000, 1.3000, 0.0000` | World origin coordinate of gaze rays |
| `centroid_dir_x/y/z` | Float | `0.0500, -0.0200, 0.9980` | World normalized mean direction vector |
| `is_valid` | Boolean | `true` | Validity confirmation flag |
