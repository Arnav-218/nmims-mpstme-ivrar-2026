# Subsystem Limitations & Methodological Constraints

**Subsystem Owner:** Person 1 (Eye-Gaze & Attention Tracking Specialist)  
**Target Engine:** Unity 6 (6000.5.3f1)  
**Namespace:** `IVRAR.CybersecurityVR`

---

## 1. Hardware & Sensor Limitations

### 1.1 Temporal Resolution (72–90 Hz vs. High-End Eye Trackers)
- Consumer and standalone enterprise XR headsets (Meta Quest Pro, Vive Focus 3) typically sample gaze at **72 Hz to 90 Hz** (occasionally 120 Hz).
- While this is well above the Nyquist rate required for identifying fixations ($\ge 150\text{ ms}$ duration), it is insufficient for resolving micro-saccadic dynamics or precise intra-saccadic trajectory kinematics typically studied with $250\text{--}1000\text{ Hz}$ desktop eye trackers (e.g. EyeLink or Tobii Pro Spectrum).
- **Mitigation:** The subsystem focuses on spatial fixation dwell and aggregate transition metrics rather than micro-saccade kinematics.

### 1.2 Peripheral Accuracy Degradation
- Eye tracking accuracy is highest within the central $10^\circ\text{--}15^\circ$ of the visual field. Beyond $20^\circ$ eccentricity, optical distortions from headset lenses and camera perspectives can increase gaze error from $\sim 0.5^\circ$ to $1.5^\circ\text{--}2.5^\circ$.
- **Mitigation:** The virtual workstation and email panel (owned by Person 3) should be placed at an ergonomic viewing distance of $1.0\text{--}1.4\text{ m}$ directly in front of the user, subtending approximately $30^\circ \times 20^\circ$ visual angle, keeping diagnostic elements within the high-accuracy foveal zone.

### 1.3 Optical Slippage and Headset Drift
- Physical headset slippage during head movement or facial expressions can shift eye camera alignment relative to the pupils, causing progressive drift over long sessions.
- **Mitigation:** Trials are kept concise ($< 30\text{ s}$ per email scenario), and recalibration can be triggered between blocks.

---

## 2. Psychological & Cognitive Limitations

### 2.1 Overt vs. Covert Attention (Look-But-Fail-To-See)
- Gaze tracking measures **overt attention** (where the fovea is oriented). It cannot directly measure **covert attention** (mental processing of peripheral cues).
- A participant may fixate on the `SenderDomain` AOI for $400\text{ ms}$ without consciously encoding the typographical discrepancy (e.g., `micros0ft.com` vs `microsoft.com`) due to confirmation bias or cognitive overload.
- **Mitigation:** High $R_{inspect}$ demonstrates that the visual threat was inspected, but does not prove comprehension. Cross-referencing $R_{inspect}$ with the behavioral decision outcome (owned by Person 2) provides the true measure of cognitive threat recognition.

### 2.2 Saccadic Suppression
- During fast saccadic gaze movements ($> 300^\circ/\text{s}$), the human visual system experiences saccadic suppression (temporary suspension of visual perception).
- **Mitigation:** The subsystem's I-DT algorithm includes an angular velocity gate that rejects samples during saccades, ensuring that AOIs crossed mid-saccade are never falsely credited with attention dwell.

---

## 3. Simulator Mode Constraints

### 3.1 Mouse-Raycast Approximation
- In interactive simulation mode (`Simulated_Interactive`), gaze direction is driven by the 2D mouse cursor in the Game view.
- While effective for verifying AOI raycasts, trigger priorities, and UI layout without a VR headset, mouse dynamics do not exhibit human saccadic acceleration, physiological tremor, or spontaneous microsaccades.
- **Mitigation:** All data gathered in simulation mode is explicitly tagged `is_synthetic = true` and must never be pooled with genuine empirical data.
