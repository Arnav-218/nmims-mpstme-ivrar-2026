# Metrics Definitions: Eye-Gaze & Attention Tracking Subsystem

**Subsystem Owner:** Person 1 (Eye-Gaze & Attention Tracking Specialist)  
**Target Engine:** Unity 6 (6000.5.3f1)  
**Namespace:** `IVRAR.CybersecurityVR`

---

## 1. Threat Inspection Ratio ($R_{inspect}$)

### 1.1 Core Mathematical Formula
The Threat Inspection Ratio measures the proportion of total email stimulus attention directed toward diagnostic indicators of phishing authenticity versus peripheral or non-diagnostic content:

$$R_{inspect} = \frac{T_{sender} + T_{domain} + T_{hyperlink}}{T_{total\_dwell}}$$

Where:
- $T_{sender}$: Dwell time on `AOIType.SenderHeader` (display name / header region).
- $T_{domain}$: Dwell time on `AOIType.SenderDomain` (exact sender domain address).
- $T_{hyperlink}$: Dwell time on `AOIType.HyperlinkTarget` (embedded link URL/hover).
- $T_{total\_dwell}$: Sum of dwell across **all** defined email stimulus AOIs (`SenderHeader`, `SenderDomain`, `HyperlinkTarget`, `SecurityBadge`, `SubjectLine`, `EmailBody`), **strictly excluding** `IrrelevantBackground`.

### 1.2 Security Badge Diagnostic Switch
By default, `IncludeSecurityBadgeInDiagnostic = false`. If toggled to `true`, the security badge dwell is included in the diagnostic numerator:

$$R_{inspect}^{(badge)} = \frac{T_{sender} + T_{domain} + T_{hyperlink} + T_{security\_badge}}{T_{total\_dwell}}$$

### 1.3 Secondary Metric: Normalized Inspection Ratio
To account for off-stimulus time (looking around the virtual office), the secondary metric normalizes diagnostic dwell over total trial observation time:

$$R_{inspect\_over\_T\_total} = \frac{T_{diagnostic\_dwell}}{T_{total\_observation\_time}}$$

---

## 2. Edge-Case Flags and Zero Handling

To ensure numerical stability in statistical pipelines (consumed by Person 4), the ratio avoids division by zero:

| Condition | $R_{inspect}$ Value | Export String | `r_inspect_flag` | Meaning |
|---|---|---|---|---|
| $T_{total\_dwell} > 0$ and Tracking Validity $\ge 50\%$ | Decimal (0.0 to 1.0) | `"0.4500"` | `"OK"` | Reliable observation |
| $T_{total\_dwell} == 0$ (No dwell on email) | `float.NaN` | `"NA"` | `"NA_NO_DWELL"` | Participant never fixated email AOIs |
| Tracking Validity $< 50\%$ | Decimal (0.0 to 1.0) | `"0.3200"` | `"LOW_VALIDITY"` | Excessive tracking loss during trial |

---

## 3. Worked Numerical Examples
> **NOTICE:** The following numbers are purely **illustrative, not empirical results**, provided solely to verify algorithm arithmetic.

### Example A: Comprehensive Threat Inspection
- Observation time ($T_{total}$): $6000.0\text{ ms}$ ($6.0\text{ s}$)
- Valid tracking time: $5700.0\text{ ms}$ (Validity ratio = $95.0\% \ge 50\%$)
- Dwell times:
  - $T_{sender} = 400.0\text{ ms}$
  - $T_{domain} = 800.0\text{ ms}$
  - $T_{hyperlink} = 1200.0\text{ ms}$
  - $T_{subject} = 600.0\text{ ms}$
  - $T_{body} = 2000.0\text{ ms}$
  - $T_{security} = 0.0\text{ ms}$
- Calculations:
  - $T_{diagnostic} = 400 + 800 + 1200 = 2400.0\text{ ms}$
  - $T_{total\_dwell} = 2400 + 600 + 2000 = 5000.0\text{ ms}$
  - $R_{inspect} = \frac{2400.0}{5000.0} = 0.4800$
  - `r_inspect_flag` = `"OK"`
  - $R_{inspect\_over\_T\_total} = \frac{2400.0}{6000.0} = 0.4000$

### Example B: Superficial Body Reading (Zero Domain Inspection)
- Dwell times:
  - $T_{sender} = 200.0\text{ ms}$
  - $T_{domain} = 0.0\text{ ms}$
  - $T_{hyperlink} = 0.0\text{ ms}$
  - $T_{subject} = 400.0\text{ ms}$
  - $T_{body} = 3400.0\text{ ms}$
- Calculations:
  - $T_{diagnostic} = 200.0\text{ ms}$
  - $T_{total\_dwell} = 200 + 0 + 0 + 400 + 3400 = 4000.0\text{ ms}$
  - $R_{inspect} = \frac{200.0}{4000.0} = 0.0500$
  - `r_inspect_flag` = `"OK"`

### Example C: Immediate Report (Zero Stimulus Dwell)
- Participant immediately hits reporting lever without fixating the email panel.
- $T_{total\_dwell} = 0.0\text{ ms}$
- $R_{inspect} = \text{float.NaN}$
- Exported as: `NA` with `r_inspect_flag = "NA_NO_DWELL"`

---

## 4. Dwell Modes & Temporal Metrics

### 4.1 Dwell Modes
1. **`DwellMode.FixationBased` (Primary):**
   Attention dwell is credited to an AOI **only** when a confirmed spatial fixation (duration $\ge 150\text{ms}$, dispersion $\le 1.0^\circ$) rests on that AOI. This is the gold standard for cognitive attention.
2. **`DwellMode.RawSample` (Secondary):**
   Raw sample duration accumulated during AOI intersection. Exported alongside fixation dwell for comparison.

### 4.2 Per-AOI Temporal Metrics
- **Time-to-First-Fixation (TTFF):** Elapsed time from trial start to the onset of the first confirmed fixation on this AOI (in ms). Exported as `"NA"` if the AOI was never fixated.
- **First-Fixation Order:** 1-indexed rank of when this AOI was first fixated relative to other AOIs (e.g. 1 = first AOI looked at).
- **Revisit Count:** Number of times the participant fixated this AOI, shifted gaze to another AOI, and subsequently returned to this AOI.
