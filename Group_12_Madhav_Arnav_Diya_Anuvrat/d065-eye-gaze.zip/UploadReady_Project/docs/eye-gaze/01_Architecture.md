# Architecture: Eye-Gaze & Attention Tracking Subsystem

**Subsystem Owner:** Person 1 (Eye-Gaze & Attention Tracking Specialist)  
**Research Context:** "To what extent does an immersive VR phishing simulation improve threat recognition and mitigate cognitive bias compared to standard 2D web-based cybersecurity training across a 14-day retention interval?"  
**Target Engine:** Unity 6 (6000.5.3f1)  
**Namespace:** `IVRAR.CybersecurityVR`

---

## 1. Architectural Overview & Component Decoupling

The subsystem is architected according to strict separation of concerns into four independent layers:
1. **Acquisition Layer (`IGazeSampleProvider`):** Pure acquisition of 3D gaze rays and tracking state. Decoupled from physics and algorithms.
2. **Spatial Detection Layer (`GazeAOITarget`, `GazeAOIRegistry`):** Non-allocating physics raycasting (`Physics.RaycastNonAlloc`) against registered email stimulus colliders with deterministic priority resolution.
3. **Temporal Filtering & Fixation Layer (`FixationDetector`):** Pure C# implementation of angular Identification by Dispersion-Threshold (I-DT), saccade velocity gating, and mini-gap bridging. Scene-independent and headless testable.
4. **Metrics & Export Layer (`GazeMetricsAccumulator`, `GazeCsvWriter`):** Accumulates dwell time per AOI across chosen dwell modes, evaluates the Threat Inspection Ratio ($R_{inspect}$), generates research flags, and produces RFC 4180 CSV tables with companion JSON metadata.

```mermaid
flowchart TD
    A[Gaze Acquisition Provider] -->|GazeSample: origin, dir, valid, timestamp| B[EyeGazeAttentionTracker]
    B -->|Physics.RaycastNonAlloc| C[GazeAOIRegistry & Colliders]
    C -->|AOIType & AOI ID| B
    B -->|Sample + AOI Hit| D[FixationDetector: I-DT in Angular Space]
    D -->|Completed FixationRecord| E[GazeMetricsAccumulator]
    B -->|Raw Sample Timing| E
    E -->|GazeTrialSummary| F[GazeCsvWriter]
    F -->|RFC 4180 Tables| G[trial_summary.csv / aoi_metrics.csv / fixations.csv]
    F -->|Companion JSON| H[session_metadata.json]
```

---

## 2. Core Subsystem Components

### 2.1 EyeGazeAttentionTracker (`Assets/Scripts/EyeGazeAttentionTracker.cs`)
Central coordinator MonoBehaviour.
- Manages active acquisition provider based on `TrackerPolicy`.
- Validates the presence of user layer `GazeAOI`.
- Dispatches raycasts on `Update()` using a preallocated `RaycastHit[16]` buffer.
- Feeds samples to `FixationDetector` and `GazeMetricsAccumulator`.
- Exposes trial lifecycle API: `BeginTrial()`, `EndTrial()`, `AbortTrial()`, `ExportTrial()`, `ResetTracker()`.
- Dispatches C# events for team integration: `OnFixationCompleted`, `OnTrialMetricsReady`, `OnProviderChanged`, `OnTrackingLost`, `OnTrackingRegained`.

### 2.2 Acquisition Providers (`Assets/Scripts/Gaze/`)
- **`OpenXREyeGazeProvider`:** Genuine OpenXR Eye Gaze provider querying Unity Input System standard layout bindings (`<EyeGaze>/pose`, `<EyeGaze>/trackingState`). Converts tracking-space poses to world space via the tracking origin / camera hierarchy. Discovers devices dynamically via `InputSystem.onDeviceChange`.
- **`HeadDirectionFallbackProvider`:** Fallback utilizing camera forward vector. Explicitly labelled `HeadDirection_Fallback` and confidence set to `float.NaN`.
- **`SimulatedGazeProvider`:** Zero-dependency simulator supporting both interactive Game-view mouse raycasting (with spacebar/B blink and L tracking loss simulation) and deterministic scripted playback.

### 2.3 AOI Registry & Collider System (`Assets/Scripts/Gaze/`)
- **`GazeAOITarget`:** Component marking an Area of Interest with an `AOIType`, unique stable ID, and raycast priority.
- **`GazeAOIRegistry`:** Static registry providing $O(1)$ dictionary lookups from hit `Collider` to `GazeAOITarget`, eliminating `GetComponent` or `GameObject.Find` in hot loops.
- **`GazeAOIColliderFitter`:** Automatic utility to fit a `BoxCollider` with configurable Z-thickness to a `RectTransform` or `TextMeshProUGUI` text bounds.

### 2.4 Fixation Detector (`Assets/Scripts/Gaze/FixationDetector.cs`)
- Pure C# class implementing 3D angular I-DT.
- Computes maximum angular dispersion between gaze vectors in visual degrees.
- Saccade velocity gate ($> 300^\circ/\text{s}$) rejects rapid transitions and prevents misattributing dwell to crossed regions.
- Gap bridging ($t_{gap} \le 75\text{ms}$): bridges mini-blinks while explicitly excluding gap duration from gaze dwell.

### 2.5 Metrics Accumulator (`Assets/Scripts/Gaze/GazeMetricsAccumulator.cs`)
- Computes per-AOI dwell across two independent modes: `FixationBased` (primary) and `RawSample` (secondary).
- Calculates Time-to-First-Fixation (TTFF), visit order, and revisit counts.
- Calculates Threat Inspection Ratio ($R_{inspect}$) with edge-case handling (NaN export on zero dwell with `NA_NO_DWELL` flag; `LOW_VALIDITY` flag on tracking coverage $< 50\%$).

### 2.6 CSV Writer (`Assets/Scripts/Gaze/GazeCsvWriter.cs`)
- Implements strict RFC 4180 escaping (commas, quotes, newlines).
- Formats all numerical values using `CultureInfo.InvariantCulture`.
- Strictly routes synthetic/simulated trials to `EyeGazeData_Synthetic/<sessionId>/` and real trials to `EyeGazeData/<sessionId>/`.
- Emits companion `session_metadata.json` recording environment, thresholds, and provenance.

### 2.7 Integration Adapters (`Assets/Scripts/Gaze/`)
- **`EyeGazeScenarioBridge`:** Adapter listening to scenario manager lifecycle events and forwarding them to `EyeGazeAttentionTracker`.
- **`MockPhishingSimulationManager`:** Test fixture representing Person 2's scenario manager, enabling headless and PlayMode verification.
