# Eye-Gaze & Attention Tracking Subsystem: Setup & Integration Guide

**Subsystem Owner:** Person 1 (Eye-Gaze & Attention Tracking Specialist)  
**Research Context:** "To what extent does an immersive VR phishing simulation improve threat recognition and mitigate cognitive bias compared to standard 2D web-based cybersecurity training across a 14-day retention interval?"  
**Target Engine:** Unity 6 (6000.5.3f1)  
**Namespace:** `IVRAR.CybersecurityVR`

---

## 1. Quick Start: Testing the Built-in Simulator (No VR Headset Needed)

You do **not** need a VR headset or the Meta XR Simulator to develop and test:
1. Open the test scene or add an empty GameObject named `[GazeTracker]` in your active scene.
2. Add the component `EyeGazeAttentionTracker` to `[GazeTracker]`.
3. Set **Gaze Acquisition Policy** to `SimulatorOnly` in the Inspector.
4. Set **Simulation Sub Mode** to `InteractiveMouse`.
5. Ensure your scene has a Main Camera tagged `MainCamera`.
6. Add `TestEmailStimulusBuilder` to an empty GameObject and click **Build Test Email Stimulus** in the Inspector context menu (or enter Play Mode).
7. Press **Play**:
   - Move your mouse over the Game view: the gaze ray follows the mouse position via `ScreenPointToRay`.
   - Press **Space** or **B** to simulate a human eye blink.
   - Press **L** to simulate a temporary loss of tracking.
   - Look at the console or on-screen status banner confirming `GAZE TRACKING STATUS: [Simulated_Interactive]`.

---

## 2. Unity Editor Configuration (Manual Setup Steps)

### 2.1 Layer Setup (`GazeAOI`)
The tracker strictly validates the presence of the `GazeAOI` layer. If missing, it halts with an error and will never silently raycast on the `Default` layer.
1. In the Unity Editor menu, select **Edit -> Project Settings -> Tags and Layers**.
2. Expand the **Layers** foldout.
3. In any empty user layer slot (e.g. **User Layer 6**), type exactly:
   ```
   GazeAOI
   ```
4. On your email panel and AOI GameObjects, set their Layer to `GazeAOI`.
5. On the `EyeGazeAttentionTracker` component, set **Gaze Aoi Layer Mask** to include `GazeAOI`.

### 2.2 Active Input Handling
The project is configured with `activeInputHandler: 1` (`com.unity.inputsystem` 1.19.0). Legacy `UnityEngine.Input` is disabled.
- All subsystem scripts are pre-configured to use the active Input System (`Mouse.current`, `Keyboard.current`, `<EyeGaze>/pose`) and will **never** throw `InvalidOperationException`.
- Assembly Definition `IVRAR.CybersecurityVR.asmdef` references `Unity.InputSystem` and `Unity.TextMeshPro`.

---

## 3. Genuine OpenXR Eye Tracking Setup (When VR Headset is Available)

To enable genuine eye tracking on hardware (e.g. Meta Quest Pro or OpenXR compatible headset):

### 3.1 Install OpenXR Packages via Package Manager
1. Open **Window -> Package Manager**.
2. Click the **+** icon in the top-left and select **Add package by name...**:
   - Name: `com.unity.xr.openxr`
   - Version: `1.14.3` (or latest compatible for Unity 6)
   - Click **Add**.
3. Also add:
   - Name: `com.unity.xr.management`
   - Version: `4.5.3` (or latest compatible)
4. (Optional for interaction components):
   - Name: `com.unity.xr.interaction.toolkit`
   - Version: `3.0.7` (or latest compatible)

### 3.2 Enable OpenXR and Eye Gaze Interaction Feature
1. Open **Edit -> Project Settings -> XR Plug-in Management**.
2. Check the box for **OpenXR** under the Standalone tab and Android tab.
3. Click on **OpenXR** in the Project Settings tree.
4. Under **Interaction Profiles**, click **+** and add:
   - **Eye Gaze Interaction Profile** (`XR_EXT_eye_gaze_interaction`).
5. Under **OpenXR Feature Groups**, ensure the **Eye Gaze Interaction** feature is enabled.

### 3.3 Android / Meta Quest Permissions (Meta Quest Pro)
If deploying to Meta Quest Pro:
1. In `Project Settings -> XR Plug-in Management -> OpenXR -> Android Tab`:
2. Enable the **Meta Quest Support** feature.
3. Ensure eye tracking permission is checked in the Android Manifest:
   ```xml
   <uses-permission android:name="com.oculus.permission.EYE_TRACKING" />
   <uses-feature android:name="oculus.software.eye_tracking" android:required="true" />
   ```

---

## 4. AOI Object & Collider Configuration

For Person 3 (Workstation & UI Specialist):
1. **Collider Type:** All email AOI elements require a 3D `BoxCollider`. Sizing should match the visual bounds with a Z-thickness of approximately `0.02m` ($2\text{ cm}$).
2. **Trigger Mode:** Set `BoxCollider.isTrigger = true` so colliders do not block UI clicks or physical interactions.
3. **GazeAOITarget Component:** Add `GazeAOITarget` to each interactive region and configure:
   - `SenderHeader`: Type = `SenderHeader`, Priority = `10`, ID = `"sender_header"`
   - `SenderDomain`: Type = `SenderDomain`, Priority = `20` (Higher priority ensures domain wins when clicked inside header), ID = `"sender_domain"`
   - `HyperlinkTarget`: Type = `HyperlinkTarget`, Priority = `20` (Higher priority ensures link wins over email body), ID = `"hyperlink_target"`
   - `SecurityBadge`: Type = `SecurityBadge`, Priority = `15`, ID = `"security_badge"`
   - `SubjectLine`: Type = `SubjectLine`, Priority = `10`, ID = `"subject_line"`
   - `EmailBody`: Type = `EmailBody`, Priority = `1`, ID = `"email_body"`
4. **Automatic Sizing Tool:** Add `GazeAOIColliderFitter` to any UI/TMP object and click **Fit Collider to Bounds** in the component context menu, or use menu item **IVRAR -> Fit All AOI Colliders in Scene**.

---

## 5. Team Coordination & Interfaces

### 5.1 For Person 2 (Scenario & Trial Lifecycle)
Connect your `PhishingThreatSimulationManager` to `EyeGazeScenarioBridge` or invoke `EyeGazeAttentionTracker` directly:
```csharp
// At the moment an email trial is presented to the user:
var context = new TrialContext(participantPseudoId, sessionId, trialId, scenarioId, conditionLabel);
tracker.BeginTrial(context);

// At the moment the participant pulls the report lever or makes a decision:
var outcomeInfo = new TrialOutcomeInfo(PhishingTrialOutcome.CorrectReport, responseTimeMs, "LEVER_REPORT");
tracker.EndTrial(outcomeInfo);

// If the trial is aborted or timed out:
tracker.AbortTrial("ParticipantTimeout");
```

### 5.2 For Person 4 (Data Analysis & Human Factors)
All session data is exported as clean, standard CSV tables:
- **Location:**
  - Real sessions: `<persistentDataPath>/EyeGazeData/<sessionId>/`
  - Synthetic / Pilot sessions: `<persistentDataPath>/EyeGazeData_Synthetic/<sessionId>/`
- **Key Columns in `trial_summary.csv`:**
  - `participant_pseudo_id`: Pseudonym (e.g. `P01` or `SYNTH-01`)
  - `provenance`: Guaranteed provenance (`EyeTracking_OpenXR` vs `Simulated_Interactive` vs `HeadDirection_Fallback`)
  - `r_inspect`: Threat Inspection Ratio ($T_{diagnostic} / T_{total\_dwell}$)
  - `r_inspect_flag`: Data quality flag (`OK`, `NA_NO_DWELL`, `LOW_VALIDITY`)
  - `t_sender_domain_ms`, `t_hyperlink_target_ms`: Diagnostic inspection dwell times
  - `t_total_dwell_ms`: Total stimulus dwell time
  - `tracking_validity_ratio`: Percentage of trial with valid tracking coverage

---

## 6. Privacy & Research Ethics Compliance Note

- **Pseudonymization:** All participant records use pseudonyms only (`P01`, `P02`). No names, student IDs, IP addresses, MAC addresses, or device serials are ever recorded or exported.
- **Local Storage Only:** All gaze metrics are written to local disk storage (`Application.persistentDataPath`). No data is transmitted across any network.
- **Informed Consent Notice:** Before collecting data on genuine headsets, ensure participants are informed that eye movement coordinates are tracked solely for threat recognition research, with no biometric identification or iris scanning performed.

---

## 7. Troubleshooting Guide

| Issue | Likely Cause | Exact Solution |
|---|---|---|
| `Layer 'GazeAOI' is not defined in TagManager` | The `GazeAOI` layer has not been created in Project Settings | Go to `Edit -> Project Settings -> Tags and Layers`. Add `GazeAOI` to User Layer 6. |
| Tracker logs `Policy is RequireRealEyeTracking, but real eye tracking hardware is unavailable` | Headset not connected or OpenXR package not installed | Check USB/AirLink connection, verify OpenXR package is installed, or set policy to `SimulatorOnly` or `PreferRealThenFallback` for development. |
| Raycast does not hit email AOIs | Colliders missing, not on `GazeAOI` layer, or distance $> 15\text{m}$ | Add `BoxCollider` to AOI GameObjects, set Layer to `GazeAOI`, and verify collider bounds using Gizmos. |
| `r_inspect` is exported as `NA` | Participant never fixated email AOIs ($T_{total\_dwell} = 0$) | Expected behavior when user looks away or immediately reports without inspecting. Flag is recorded as `NA_NO_DWELL`. |
| Gaze jitter in simulator mode | Noise amplitude setting on scripted sequence | Set `noiseDegrees = 0` in `ScriptedGazeStep` for perfectly still gaze. |
